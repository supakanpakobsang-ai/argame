<?php
// php/index.php
// หน้าหลักและล็อกอินสำหรับระบบสมัครนักกีฬาอีสปอร์ต

session_start();
require_once 'db.config.php';

// หากล็อกอินอยู่แล้ว ส่งไปหน้าเกม
if (isset($_SESSION['user_id'])) {
    header("Location: game.php");
    exit();
}

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if (!empty($username) && !empty($password)) {
        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username");
            $stmt->execute(['username' => $username]);
            $user = $stmt->fetch();

            // ตรวจสอบรหัสผ่านโดยใช้ password_verify กับรหัสที่เข้ารหัสไว้ในฐานข้อมูล
            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['name'] = $user['name'];
                $_SESSION['high_score'] = $user['high_score'];
                
                header("Location: game.php");
                exit();
            } else {
                $error = "Username หรือ Password ไม่ถูกต้อง!";
            }
        } catch (PDOException $e) {
            $error = "เกิดข้อผิดพลาดในการเชื่อมต่อ: " . $e->getMessage();
        }
    } else {
        $error = "กรุณากรอกข้อมูลให้ครบถ้วน!";
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ESPORTS RECRUITMENT | ประตูสู่วงการอีสปอร์ตระดับโลก</title>
    <!-- ใช้ Tailwind CSS CDN สำหรับการดีไซน์แนวเกมมิ่งที่สวยงาม -->
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .neon-border {
            box-shadow: 0 0 15px rgba(168, 85, 247, 0.4), 0 0 5px rgba(168, 85, 247, 0.2);
        }
        .neon-text {
            text-shadow: 0 0 10px rgba(168, 85, 247, 0.6);
        }
        .neon-btn:hover {
            box-shadow: 0 0 20px rgba(168, 85, 247, 0.8);
            transition: all 0.3s ease;
        }
    </style>
</head>
<body class="bg-[#0b0c10] text-[#c5c6c7] font-sans min-h-screen flex flex-col justify-between">

    <!-- Header / Navigation -->
    <header class="border-b border-purple-900/40 bg-[#1f2833]/30 backdrop-blur-md">
        <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <div class="flex items-center space-x-2">
                <span class="text-2xl font-black tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-purple-500 to-pink-500 neon-text">
                    NEXUS ESPORTS
                </span>
            </div>
            <div class="text-xs text-purple-400 font-mono tracking-wider bg-purple-950/40 px-3 py-1.5 rounded-full border border-purple-800/50">
                PRO SELECTION ROUND
            </div>
        </div>
    </header>

    <!-- Main Content Grid -->
    <main class="max-w-7xl mx-auto px-4 py-12 flex-grow grid grid-cols-1 lg:grid-cols-2 gap-12 items-center w-full">
        
        <!-- ข้อมูลแนะนำโครงการ / มโนเนื้อหา -->
        <div class="space-y-6">
            <div class="inline-block bg-purple-950/50 text-purple-400 border border-purple-800/60 px-4 py-1.5 rounded text-xs font-bold tracking-wider uppercase">
                Now Recruiting 2026
            </div>
            <h1 class="text-4xl md:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-none">
                ก้าวข้ามขีดจำกัด<br>
                <span class="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500">
                    สู่นักกีฬาอีสปอร์ตมืออาชีพ
                </span>
            </h1>
            <p class="text-gray-400 leading-relaxed text-base md:text-lg">
                โอกาสทองครั้งสำคัญในการก้าวเข้าสู่ทีม <span class="text-purple-400 font-semibold">NEXUS ESPORTS</span> สังกัดชั้นนำระดับโลก 
                เรากำลังเฟ้นหานักกีฬาหน้าใหม่ที่มีความสามารถเชิงปฏิกิริยาการตอบสนองที่ฉับไว แม่นยำ และมีความตั้งใจจริง
            </p>
            
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4">
                <div class="p-4 rounded-lg bg-[#1f2833]/40 border border-purple-900/30">
                    <div class="text-2xl font-bold text-white text-purple-400">100K+ USD</div>
                    <div class="text-xs text-gray-500 mt-1">เงินรางวัลและสัญญาอาชีพ</div>
                </div>
                <div class="p-4 rounded-lg bg-[#1f2833]/40 border border-purple-900/30">
                    <div class="text-2xl font-bold text-white text-pink-400">AR TRAINING</div>
                    <div class="text-xs text-gray-500 mt-1">ทดสอบปฏิกิริยาด้วยมือเปล่า</div>
                </div>
                <div class="p-4 rounded-lg bg-[#1f2833]/40 border border-purple-900/30">
                    <div class="text-2xl font-bold text-white text-purple-400">GLOBAL TEAM</div>
                    <div class="text-xs text-gray-500 mt-1">การสนับสนุนระดับสากล</div>
                </div>
            </div>

            <div class="p-4 rounded-lg bg-yellow-500/10 border border-yellow-500/20 text-yellow-500 text-sm">
                💡 <strong>ขั้นตอนการทดสอบคัดเลือก:</strong> สมัครสมาชิก > เข้าสู่ระบบ > ทำการทดสอบผ่านกล้อง Webcam ในด่าน AR Hand Tracker > บันทึกคะแนนสถิติสูงสุดเพื่อติดอันดับผู้นำ (Leaderboard)
            </div>
        </div>

        <!-- ฟอร์มล็อกอิน -->
        <div class="w-full max-w-md mx-auto bg-[#1f2833]/60 p-8 rounded-2xl border border-purple-900/30 neon-border backdrop-blur-sm">
            <h2 class="text-2xl font-bold text-white mb-6 tracking-wide text-center uppercase">
                <span class="text-purple-500">PLAYER</span> LOGIN
            </h2>

            <?php if (!empty($error)): ?>
                <div class="mb-4 p-3 bg-red-900/40 border border-red-500 text-red-200 text-sm rounded text-center">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <form action="index.php" method="POST" class="space-y-4">
                <div>
                    <label for="username" class="block text-xs font-mono text-gray-400 uppercase tracking-widest mb-1.5">
                        Username (ชื่อผู้ใช้)
                    </label>
                    <input type="text" name="username" id="username" placeholder="ระบุผู้ใช้ของคุณ" required
                           class="w-full bg-[#0b0c10] border border-purple-900/40 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-purple-500 transition-colors">
                </div>

                <div>
                    <label for="password" class="block text-xs font-mono text-gray-400 uppercase tracking-widest mb-1.5">
                        Password (รหัสผ่าน)
                    </label>
                    <input type="password" name="password" id="password" placeholder="••••••••" required
                           class="w-full bg-[#0b0c10] border border-purple-900/40 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-purple-500 transition-colors">
                </div>

                <button type="submit" class="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white font-bold py-3 px-4 rounded-lg transition-all duration-300 neon-btn tracking-wider uppercase mt-2">
                    เข้าสู่ระบบ / LOG IN
                </button>
            </form>

            <div class="mt-6 pt-6 border-t border-purple-900/20 text-center space-y-3">
                <p class="text-sm text-gray-400">ยังไม่มีไอดีผู้ใช้ในสังกัดของเรา?</p>
                <a href="register.php" class="inline-block w-full bg-transparent hover:bg-purple-950/30 text-purple-400 hover:text-white border border-purple-500/50 hover:border-purple-500 font-bold py-2.5 px-4 rounded-lg transition-all duration-300 text-center tracking-wider uppercase">
                    ลงทะเบียนผู้สมัคร (Register)
                </a>
            </div>
        </div>

    </main>

    <!-- Footer -->
    <footer class="border-t border-purple-900/20 bg-black/40 py-6 text-center text-xs text-gray-500">
        <div class="max-w-7xl mx-auto px-4">
            <p>&copy; 2026 NEXUS ESPORTS CLUB. All Rights Reserved. Selection Server v1.0.4</p>
        </div>
    </footer>

</body>
</html>
