-- php/schema.sql
-- คำสั่งสำหรับสร้างฐานข้อมูลและตารางสำหรับระบบรับสมัครนักกีฬาอีสปอร์ต
-- สามารถนำรหัสนี้ไปรันในเมนู SQL ของ phpMyAdmin ใน AppServ ได้เลยครับ

-- 1. สร้างฐานข้อมูล (ถ้ายังไม่มี)
CREATE DATABASE IF NOT EXISTS `esports_db` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `esports_db`;

-- 2. สร้างตาราง users เก็บข้อมูลผู้สมัครและคะแนนสูงสุด
CREATE TABLE IF NOT EXISTS `users` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `username` VARCHAR(50) NOT NULL UNIQUE,
    `password` VARCHAR(255) NOT NULL, -- เก็บ password ที่ผ่านการทำ password_hash()
    `name` VARCHAR(100) NOT NULL,
    `email` VARCHAR(100) NOT NULL UNIQUE,
    `phone` VARCHAR(20) NOT NULL,
    `high_score` INT DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
