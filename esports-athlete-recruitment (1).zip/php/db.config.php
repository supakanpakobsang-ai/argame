<?php
// php/db.config.php
// ไฟล์สำหรับเชื่อมต่อฐานข้อมูล MySQL (รองรับการใช้งานบน AppServ / phpMyAdmin)

$host = 'localhost';
$dbname = 'esports_db';
$db_user = 'root';
$db_pass = ''; // รหัสผ่านของ MySQL (ค่าเริ่มต้นของ AppServ มักเป็นค่าว่าง หรือตามที่ตั้งตอนติดตั้ง เช่น 1234)

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $db_user, $db_pass);
    // ตั้งค่าให้แสดง Error Mode เป็น Exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("เชื่อมต่อฐานข้อมูลล้มเหลว: " . $e->getMessage());
}
?>
