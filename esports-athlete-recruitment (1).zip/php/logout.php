<?php
// php/logout.php
// ไฟล์สคริปต์สำหรับออกจากระบบและทำลาย Session ทั้งหมด

session_start();
session_unset();
session_destroy();

header("Location: index.php");
exit();
?>
