<?php
// php/game.php
// หน้าทดสอบปฏิกิริยานักกีฬาอีสปอร์ตด้วยเทคโนโลยี AR จับความเคลื่อนไหวมือ (Webcam)

session_start();

// ด่านป้องกันสิทธิ์: หากผู้ใช้งานยังไม่เคยล็อกอิน ให้เด้งกลับไปหน้าหลักทันที
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

require_once 'db.config.php';

// ดึงข้อมูลผู้ใช้งานอัปเดตสุดจากฐานข้อมูล
$userId = $_SESSION['user_id'];
try {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id");
    $stmt->execute(['id' => $userId]);
    $user = $stmt->fetch();
    if ($user) {
        $_SESSION['high_score'] = $user['high_score'];
    }
} catch (PDOException $e) {
    // ดึงข้อมูลล้มเหลว ใช้คะแนนใน session ไปก่อน
}

// ตรวจสอบส่วนรับข้อมูลบันทึกคะแนนผ่าน AJAX Fetch API (POST Request)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (isset($input['score'])) {
        header('Content-Type: application/json');
        $newScore = (int)$input['score'];
        $oldHighScore = (int)$_SESSION['high_score'];
        
        $isUpdated = false;
        if ($newScore > $oldHighScore) {
            try {
                $updateStmt = $pdo->prepare("UPDATE users SET high_score = :score WHERE id = :id");
                $updateStmt->execute(['score' => $newScore, 'id' => $userId]);
                $_SESSION['high_score'] = $newScore;
                $isUpdated = true;
                echo json_encode([
                    'success' => true,
                    'isNewHighScore' => true,
                    'high_score' => $newScore,
                    'message' => 'บันทึกคะแนนสถิติสูงสุดใหม่สำเร็จ!'
                ]);
            } catch (PDOException $e) {
                echo json_encode([
                    'success' => false,
                    'message' => 'ข้อผิดพลาดระบบฐานข้อมูล: ' . $e->getMessage()
                ]);
            }
        } else {
            echo json_encode([
                'success' => true,
                'isNewHighScore' => false,
                'high_score' => $oldHighScore,
                'message' => 'คะแนนไม่เกินสถิติสูงสุดเดิม'
            ]);
        }
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ESPORTS TEST STAGE | ด่านทดสอบความไวปฏิกิริยา AR</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- โหลด MediaPipe CDNs สำหรับการตรวจจับพิกัดมือผ่านกล้องแบบเรียลไทม์ -->
    <script src="https://cdn.jsdelivr.net/npm/@mediapipe/camera_utils/camera_utils.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands.js" crossorigin="anonymous"></script>
    <style>
        .neon-border-purple {
            box-shadow: 0 0 15px rgba(168, 85, 247, 0.4);
        }
        .neon-text-pink {
            text-shadow: 0 0 10px rgba(236, 72, 153, 0.7);
        }
        .neon-text-green {
            text-shadow: 0 0 10px rgba(34, 197, 94, 0.7);
        }
    </style>
</head>
<body class="bg-[#0b0c10] text-[#c5c6c7] font-sans min-h-screen flex flex-col justify-between">

    <!-- Header -->
    <header class="border-b border-purple-900/40 bg-[#1f2833]/30 backdrop-blur-md">
        <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <span class="text-xl font-black tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-purple-500 to-pink-500">
                NEXUS RECRUITMENT STAGE
            </span>
            <div class="flex items-center space-x-4">
                <div class="text-sm">
                    ยินดีต้อนรับ: <span class="text-purple-400 font-bold"><?php echo htmlspecialchars($_SESSION['name']); ?></span> 
                    (ID: <span class="text-pink-400 font-mono"><?php echo htmlspecialchars($_SESSION['username']); ?></span>)
                </div>
                <a href="logout.php" class="bg-red-950/40 hover:bg-red-900 text-red-300 hover:text-white border border-red-800/60 px-3 py-1.5 rounded text-xs font-bold transition-all duration-200">
                    ออกจากระบบ
                </a>
            </div>
        </div>
    </header>

    <!-- Main Game Section -->
    <main class="max-w-7xl mx-auto px-4 py-8 flex-grow w-full grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        <!-- แผงคะแนนและการควบคุมด้านข้าง -->
        <div class="lg:col-span-1 space-y-6">
            <div class="bg-[#1f2833]/60 p-6 rounded-xl border border-purple-900/30 neon-border-purple">
                <h3 class="text-sm font-mono tracking-widest text-gray-400 uppercase mb-4">ข้อมูลการทดสอบ</h3>
                
                <div class="space-y-4">
                    <div class="p-3 bg-black/40 rounded border border-purple-900/20">
                        <div class="text-xs text-gray-500">คะแนนปัจจุบัน (Current Score)</div>
                        <div class="text-3xl font-black text-green-400 neon-text-green" id="currentScoreDisplay">0</div>
                    </div>

                    <div class="p-3 bg-black/40 rounded border border-purple-900/20">
                        <div class="text-xs text-gray-500">สถิติสูงสุดของคุณ (High Score)</div>
                        <div class="text-2xl font-black text-purple-400" id="personalHighScore">
                            <?php echo (int)$_SESSION['high_score']; ?> คะแนน
                        </div>
                    </div>

                    <div class="text-xs text-gray-400 leading-relaxed space-y-2">
                        <p class="font-bold text-yellow-500">🎮 กติกาการทดสอบ:</p>
                        <ul class="list-disc list-inside space-y-1">
                            <li>อนุญาตกล้องเว็บแคมเพื่อเริ่มจับความเคลื่อนไหว</li>
                            <li>ใช้ <span class="text-pink-400">ปลายนิ้วชี้</span> เลื่อนไปแตะที่ <span class="text-yellow-400">ดวงดาวนำโชค</span> บนจอ</li>
                            <li>หากไม่มีเว็บแคม สามารถใช้เมาส์คลิก/แตะดาวสำรองได้</li>
                            <li>ทำคะแนนให้เร็วและเยอะที่สุดแล้วกด "บันทึกคะแนนเข้าสู่ระบบ"</li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- ปุ่มบันทึกคะแนน -->
            <div class="bg-[#1f2833]/40 p-4 rounded-xl border border-purple-900/20 space-y-3">
                <button id="saveScoreBtn" onclick="saveScoreToDatabase()" 
                        class="w-full bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 text-white font-bold py-3 px-4 rounded-lg transition-all duration-300 text-center uppercase tracking-wide cursor-pointer text-sm">
                    💾 บันทึกคะแนนเข้าสู่ระบบ
                </button>
                <div id="statusMessage" class="text-xs text-center font-mono py-1 rounded hidden"></div>
            </div>
        </div>

        <!-- หน้าจอแสดงผลกล้อง AR / คอนโซลเกม -->
        <div class="lg:col-span-3 flex flex-col space-y-4">
            
            <div class="relative w-full aspect-video bg-black rounded-2xl overflow-hidden border border-purple-500/30 neon-border-purple flex items-center justify-center">
                <!-- วิดีโอกล้องถูกซ่อนไว้ แต่ใช้ดึงเฟรมภาพ -->
                <video id="webcam" autoplay playsinline muted width="640" height="480" class="hidden"></video>
                
                <!-- แคนวาสหลักในการวาดวิดีโอสะท้อนกระจก แอนิเมชัน และดาว -->
                <canvas id="gameCanvas" width="640" height="480" class="w-full h-full object-cover"></canvas>

                <!-- หน้าต่าง Overlay แจ้งโหลด / เปิดกล้อง -->
                <div id="loadingOverlay" class="absolute inset-0 bg-black/90 flex flex-col items-center justify-center text-center p-6 space-y-4">
                    <div class="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-purple-500"></div>
                    <div class="text-sm font-semibold">กำลังเชื่อมต่อกล้องเว็บแคมและดาวน์โหลดสมองกลปัญญาประดิษฐ์ (MediaPipe Hands AI)...</div>
                    <p class="text-xs text-gray-500">กรุณากด 'อนุญาตการเข้าถึงกล้อง' หากบราวเซอร์ร้องขอ</p>
                    <button onclick="startMouseFallback()" class="text-xs bg-purple-950 hover:bg-purple-900 text-purple-300 px-4 py-2 rounded-lg border border-purple-800 transition-colors">
                        หรือเริ่มเล่นโหมดใช้เมาส์ทันที (Mouse Fallback)
                    </button>
                </div>

                <!-- ป้ายแสดงเมื่ออยู่ในโหมดเมาส์ -->
                <div id="mouseModeBadge" class="absolute top-4 right-4 bg-yellow-500/90 text-black text-[10px] font-bold px-2 py-1 rounded hidden uppercase tracking-wider">
                    Mouse Control Active
                </div>
            </div>

            <!-- แถบระบุสถานะกล้อง -->
            <div class="flex justify-between items-center bg-[#1f2833]/30 px-4 py-2.5 rounded-lg border border-purple-950">
                <span class="text-xs text-gray-400" id="cameraStatusText">
                    สถานะกล้อง: <span class="text-yellow-400 font-bold">กำลังรันระบบคัดกรอง...</span>
                </span>
                <span class="text-[10px] font-mono text-gray-500">ความละเอียดแนะนำ: 640 x 480 พิกเซล</span>
            </div>

        </div>

    </main>

    <!-- ลอจิกเกม AR และการสื่อสาร AJAX -->
    <script>
        const videoElement = document.getElementById('webcam');
        const canvasElement = document.getElementById('gameCanvas');
        const canvasCtx = canvasElement.getContext('2d');
        const loadingOverlay = document.getElementById('loadingOverlay');
        const currentScoreDisplay = document.getElementById('currentScoreDisplay');
        const statusMessage = document.getElementById('statusMessage');
        const cameraStatusText = document.getElementById('cameraStatusText');
        const mouseModeBadge = document.getElementById('mouseModeBadge');

        // สถานะของเกม
        let score = 0;
        let isCameraActive = false;
        let isMouseMode = false;
        let star = { x: 320, y: 240, radius: 25, color: '#facc15' }; // ดาวนำโชค
        let handCursor = { x: -100, y: -100, isTracking: false }; // พิกัดนิ้วชี้ของผู้เล่น

        // สุ่มพิกัดดาวใหม่
        function spawnStar() {
            // หลีกเลี่ยงขอบจอเพื่อให้นิ้วแตะโดนง่ายขึ้น
            star.x = Math.floor(Math.random() * (canvasElement.width - 100)) + 50;
            star.y = Math.floor(Math.random() * (canvasElement.height - 100)) + 50;
        }

        // เช็กการชนกัน (Collision Detection)
        function checkCollision(x1, y1, x2, y2, r1, r2) {
            const distance = Math.hypot(x2 - x1, y2 - y1);
            return distance < (r1 + r2);
        }

        // เพิ่มคะแนน
        function incrementScore() {
            score++;
            currentScoreDisplay.textContent = score;
            spawnStar();
            // เสียงเอฟเฟกต์ยิงความถึ่สังเคราะห์แบบเรียลไทม์ (Audio Synthesizer) เพื่อความไฮเทค
            playBeepSound();
        }

        // สร้างเอฟเฟกต์เสียงด้วย Web Audio API โดยไม่ต้องพึ่งพาไฟล์เสียงภายนอก
        function playBeepSound() {
            try {
                const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
                const oscillator = audioCtx.createOscillator();
                const gainNode = audioCtx.createGain();
                
                oscillator.type = 'sine';
                oscillator.frequency.setValueAtTime(880, audioCtx.currentTime); // โน้ตความถี่สูงสะใจ
                gainNode.gain.setValueAtTime(0.1, audioCtx.currentTime);
                gainNode.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.1);
                
                oscillator.connect(gainNode);
                gainNode.connect(audioCtx.destination);
                oscillator.start();
                oscillator.stop(audioCtx.currentTime + 0.12);
            } catch (e) {
                // เบราว์เซอร์ไม่รองรับบล็อกเสียงชั่วคราว
            }
        }

        // เมื่อเริ่มโหมดใช้เมาส์เป็นสำรอง
        function startMouseFallback() {
            isMouseMode = true;
            loadingOverlay.style.display = 'none';
            mouseModeBadge.classList.remove('hidden');
            cameraStatusText.innerHTML = 'สถานะกล้อง: <span class="text-orange-400 font-bold">ใช้เมาส์ขยับเพื่อทดสอบแทนกล้อง</span>';
            spawnStar();
            requestAnimationFrame(gameLoop);
        }

        // ตรวจพิกัดเมาส์สำหรับโหมดเมาส์สำรอง
        canvasElement.addEventListener('mousemove', function(e) {
            if (!isMouseMode) return;
            const rect = canvasElement.getBoundingClientRect();
            // แปลงพิกัดการสัมผัสตามขนาดแคนวาสจริง
            handCursor.x = (e.clientX - rect.left) * (canvasElement.width / rect.width);
            handCursor.y = (e.clientY - rect.top) * (canvasElement.height / rect.height);
            handCursor.isTracking = true;
        });

        canvasElement.addEventListener('mouseleave', function() {
            if (isMouseMode) {
                handCursor.isTracking = false;
            }
        });

        // ลูปรันหน้าต่างเกม (สำหรับโหมดสำรอง และแอนิเมชันวิดีโอ)
        function gameLoop() {
            canvasCtx.clearRect(0, 0, canvasElement.width, canvasElement.height);

            if (isMouseMode) {
                // พื้นหลังสีมืดสไตล์นีออนในโหมดเมาส์
                canvasCtx.fillStyle = '#0f172a';
                canvasCtx.fillRect(0, 0, canvasElement.width, canvasElement.height);
                
                // ตกแต่งพื้นหลังสไตล์ตาราง Grid
                canvasCtx.strokeStyle = 'rgba(168, 85, 247, 0.1)';
                canvasCtx.lineWidth = 1;
                for (let i = 0; i < canvasElement.width; i += 40) {
                    canvasCtx.beginPath();
                    canvasCtx.moveTo(i, 0);
                    canvasCtx.lineTo(i, canvasElement.height);
                    canvasCtx.stroke();
                }
                for (let j = 0; j < canvasElement.height; j += 40) {
                    canvasCtx.beginPath();
                    canvasCtx.moveTo(0, j);
                    canvasCtx.lineTo(canvasElement.width, j);
                    canvasCtx.stroke();
                }
            }

            // วาดเป้าดาวนำโชค
            drawStar(canvasCtx, star.x, star.y, 5, star.radius, star.radius / 2.2, star.color);

            // วาดจุดสัมผัสของผู้เล่น
            if (handCursor.isTracking) {
                // เอฟเฟกต์จุดสีชมพูนีออนส่องสว่าง
                canvasCtx.beginPath();
                canvasCtx.arc(handCursor.x, handCursor.y, 12, 0, 2 * Math.PI);
                canvasCtx.fillStyle = 'rgba(236, 72, 153, 0.8)';
                canvasCtx.shadowBlur = 15;
                canvasCtx.shadowColor = '#ec4899';
                canvasCtx.fill();
                canvasCtx.shadowBlur = 0; // รีเซ็ต

                // วาดเป้าครอบปลายนิ้ว
                canvasCtx.beginPath();
                canvasCtx.arc(handCursor.x, handCursor.y, 22, 0, 2 * Math.PI);
                canvasCtx.strokeStyle = '#ec4899';
                canvasCtx.lineWidth = 2;
                canvasCtx.stroke();

                // ตรวจสอบความถูกต้องของการชน
                if (checkCollision(handCursor.x, handCursor.y, star.x, star.y, 12, star.radius)) {
                    incrementScore();
                }
            }

            requestAnimationFrame(gameLoop);
        }

        // ฟังก์ชันวาดรูปดวงดาวนำโชค 5 แฉก
        function drawStar(ctx, cx, cy, spikes, outerRadius, innerRadius, color) {
            let rot = Math.PI / 2 * 3;
            let x = cx;
            let y = cy;
            let step = Math.PI / spikes;

            ctx.beginPath();
            ctx.moveTo(cx, cy - outerRadius);
            for (let i = 0; i < spikes; i++) {
                x = cx + Math.cos(rot) * outerRadius;
                y = cy + Math.sin(rot) * outerRadius;
                ctx.lineTo(x, y);
                rot += step;

                x = cx + Math.cos(rot) * innerRadius;
                y = cy + Math.sin(rot) * innerRadius;
                ctx.lineTo(x, y);
                rot += step;
            }
            ctx.lineTo(cx, cy - outerRadius);
            ctx.closePath();
            
            ctx.shadowBlur = 20;
            ctx.shadowColor = color;
            ctx.fillStyle = color;
            ctx.fill();
            ctx.shadowBlur = 0; // รีเซ็ต

            // วาดเส้นขอบทองหรูหรา
            ctx.strokeStyle = '#ffffff';
            ctx.lineWidth = 1.5;
            ctx.stroke();
        }

        // ลอจิกการทำงานกล้องและ AI ตรวจจับพิกัดมือ
        function onResults(results) {
            // ลบแคนวาสเดิม
            canvasCtx.save();
            canvasCtx.clearRect(0, 0, canvasElement.width, canvasElement.height);

            // วาดภาพจากกล้องเว็บแคม (และทำ mirror สะท้อนกลับซ้ายขวาเพื่อการเล่นที่เป็นธรรมชาติ)
            canvasCtx.translate(canvasElement.width, 0);
            canvasCtx.scale(-1, 1);
            canvasCtx.drawImage(results.image, 0, 0, canvasElement.width, canvasElement.height);
            canvasCtx.restore(); // นำการหมุนกระจกกลับคืนสู่ค่าปกติ

            handCursor.isTracking = false;

            // ตรวจสอบว่ากล้องตรวจเจอมือหรือไม่
            if (results.multiHandLandmarks && results.multiHandLandmarks.length > 0) {
                const landmarks = results.multiHandLandmarks[0];
                
                // หยิบพิกัดข้อต่อที่ 8 (Index Finger Tip - ปลายนิ้วชี้)
                const indexFinger = landmarks[8];
                
                // นำพิกัดปลายนิ้วแบบ Ratio (0.0 ถึง 1.0) มาคำนวณเข้าพิกัดแคนวาสจริง
                // ทำการคำนวณ mirror จากขวามาซ้าย เนื่องจากเรากระจกกล้องวิดีโอ
                handCursor.x = (1 - indexFinger.x) * canvasElement.width;
                handCursor.y = indexFinger.y * canvasElement.height;
                handCursor.isTracking = true;
            }

            // วาดดาวดาวนำโชค
            drawStar(canvasCtx, star.x, star.y, 5, star.radius, star.radius / 2.2, star.color);

            // วาดพิกัดสัมผัสเมื่อเจอมือ
            if (handCursor.isTracking) {
                canvasCtx.beginPath();
                canvasCtx.arc(handCursor.x, handCursor.y, 14, 0, 2 * Math.PI);
                canvasCtx.fillStyle = 'rgba(168, 85, 247, 0.9)'; // สีม่วงนีออน
                canvasCtx.shadowBlur = 15;
                canvasCtx.shadowColor = '#a855f7';
                canvasCtx.fill();
                canvasCtx.shadowBlur = 0;

                canvasCtx.beginPath();
                canvasCtx.arc(handCursor.x, handCursor.y, 25, 0, 2 * Math.PI);
                canvasCtx.strokeStyle = '#22c55e'; // สีเขียวนีออนยืนยันการแทรคกิ้ง
                canvasCtx.lineWidth = 2.5;
                canvasCtx.stroke();

                // ตรวจสอบการชนกันระหว่าง ปลายนิ้วผู้เล่น กับ ดาวนำโชค
                if (checkCollision(handCursor.x, handCursor.y, star.x, star.y, 14, star.radius)) {
                    incrementScore();
                }
            }
        }

        // ทำการตั้งค่ากล้องเว็บแคมผ่านโครงสร้าง MediaPipe
        const hands = new Hands({
            locateFile: (file) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`
        });

        hands.setOptions({
            maxNumHands: 1, // ติดตามเพียงมือเดียวเท่านั้นเพื่อประหยัดทรัพยากร
            modelComplexity: 1,
            minDetectionConfidence: 0.6,
            minTrackingConfidence: 0.6
        });

        hands.onResults(onResults);

        // ดักจับข้อยกเว้นกรณีเครื่องไม่มีเว็บแคมหรือปฏิเสธสิทธิ์
        const cameraObj = new Camera(videoElement, {
            onFrame: async () => {
                if (!isMouseMode) {
                    await hands.send({ image: videoElement });
                }
            },
            width: 640,
            height: 480
        });

        cameraObj.start()
            .then(() => {
                isCameraActive = true;
                loadingOverlay.style.display = 'none';
                cameraStatusText.innerHTML = 'สถานะกล้อง: <span class="text-green-400 font-bold">🟢 ทำงานสมบูรณ์ (โหมดวิเคราะห์ขยับมือเปิดใช้งาน)</span>';
                spawnStar();
            })
            .catch((err) => {
                console.warn("ไม่สามารถเรียกกล้องหน้าได้ กำลังเปลี่ยนเข้าสู่โหมดเมาส์: ", err);
                cameraStatusText.innerHTML = 'สถานะกล้อง: <span class="text-red-400 font-bold">🔴 เข้าถึงกล้องไม่ได้ เปลี่ยนเป็นโหมดเมาส์สำรองแล้ว</span>';
                startMouseFallback();
            });


        // ฟังก์ชันส่งบันทึกคะแนนไปยังฝั่งเซิร์ฟเวอร์ด้วย Fetch API (AJAX)
        function saveScoreToDatabase() {
            const saveBtn = document.getElementById('saveScoreBtn');
            saveBtn.disabled = true;
            saveBtn.innerHTML = 'กำลังทำรายการ...';

            statusMessage.classList.remove('hidden', 'bg-red-950/40', 'border-red-500', 'text-red-300', 'bg-emerald-950/40', 'border-emerald-500', 'text-emerald-300');

            fetch('game.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ score: score })
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('ไม่สามารถบันทึกข้อมูลกับเซิร์ฟเวอร์ได้');
                }
                return response.json();
            })
            .then(data => {
                statusMessage.classList.remove('hidden');
                
                if (data.success) {
                    // อัปเดตแสดงคะแนนสูงสุดของสิทธิ์ผู้ใช้ในปัจจุบันบนจอ
                    document.getElementById('personalHighScore').textContent = data.high_score + ' คะแนน';
                    
                    statusMessage.className = "text-xs text-center font-mono py-2 rounded border bg-emerald-950/40 border-emerald-500 text-emerald-300";
                    if (data.isNewHighScore) {
                        statusMessage.innerHTML = '🏆 <strong>' + data.message + '</strong> (สถิติปัจจุบัน: ' + data.high_score + ' คะแนน)';
                    } else {
                        statusMessage.innerHTML = 'ℹ️ ' + data.message + ' (คะแนนสถิติเดิมของคุณยังดีกว่าที่เล่นรอบนี้)';
                    }
                } else {
                    statusMessage.className = "text-xs text-center font-mono py-2 rounded border bg-red-950/40 border-red-500 text-red-300";
                    statusMessage.textContent = '❌ ล้มเหลว: ' + data.message;
                }
            })
            .catch(error => {
                statusMessage.classList.remove('hidden');
                statusMessage.className = "text-xs text-center font-mono py-2 rounded border bg-red-950/40 border-red-500 text-red-300";
                statusMessage.textContent = '❌ เกิดข้อผิดพลาดเครือข่าย: ' + error.message;
            })
            .finally(() => {
                saveBtn.disabled = false;
                saveBtn.innerHTML = '💾 บันทึกคะแนนเข้าสู่ระบบ';
            });
        }
    </script>

    <!-- Footer -->
    <footer class="border-t border-purple-900/20 bg-black/40 py-6 text-center text-xs text-gray-500">
        <div class="max-w-7xl mx-auto px-4">
            <p>&copy; 2026 NEXUS ESPORTS CLUB. All Rights Reserved. Selection Server v1.0.4</p>
        </div>
    </footer>

</body>
</html>
