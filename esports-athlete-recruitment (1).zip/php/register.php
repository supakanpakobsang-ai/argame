<?php
// php/register.php
// หน้าลงทะเบียนสมัครสมาชิกสำหรับผู้เข้าร่วมคัดเลือกนักกีฬาอีสปอร์ต

session_start();
require_once 'db.config.php';

$success_message = "";
$error_message = "";
$generated_username = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if (!empty($name) && !empty($email) && !empty($phone) && !empty($username) && !empty($password)) {
        try {
            // ตรวจสอบข้อมูลซ้ำ
            $check_stmt = $pdo->prepare("SELECT id FROM users WHERE username = :username OR email = :email");
            $check_stmt->execute(['username' => $username, 'email' => $email]);
            
            if ($check_stmt->rowCount() > 0) {
                $error_message = "Username หรือ Email นี้ถูกลงทะเบียนไว้แล้วในระบบ!";
            } else {
                // เข้ารหัสผ่านด้วยฟังก์ชัน password_hash() ตามที่โจทย์ระบุ
                $password_hashed = password_hash($password, PASSWORD_BCRYPT);

                $insert_stmt = $pdo->prepare("INSERT INTO users (username, password, name, email, phone, high_score) VALUES (:username, :password, :name, :email, :phone, 0)");
                $insert_stmt->execute([
                    'username' => $username,
                    'password' => $password_hashed,
                    'name' => $name,
                    'email' => $email,
                    'phone' => $phone
                ]);

                // แสดงข้อความความสำเร็จและเตรียมรีไดเร็กต์
                $success_message = "ลงทะเบียนสมัครสมาชิกสำเร็จ! กำลังพากลับไปหน้าเข้าสู่ระบบ...";
            }
        } catch (PDOException $e) {
            $error_message = "เกิดข้อผิดพลาดในการบันทึกข้อมูล: " . $e->getMessage();
        }
    } else {
        $error_message = "กรุณากรอกข้อมูลให้ครบถ้วนในทุกช่อง!";
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REGISTER | ลงทะเบียนนักกีฬาอีสปอร์ต</title>
    <!-- ใช้ Tailwind CSS CDN สำหรับการดีไซน์แนวเกมมิ่ง -->
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .neon-border {
            box-shadow: 0 0 15px rgba(236, 72, 153, 0.4), 0 0 5px rgba(236, 72, 153, 0.2);
        }
        .neon-text {
            text-shadow: 0 0 10px rgba(236, 72, 153, 0.6);
        }
        .neon-btn:hover {
            box-shadow: 0 0 20px rgba(236, 72, 153, 0.8);
            transition: all 0.3s ease;
        }
    </style>
</head>
<body class="bg-[#0b0c10] text-[#c5c6c7] font-sans min-h-screen flex flex-col justify-between">

    <!-- Header / Navigation -->
    <header class="border-b border-pink-900/40 bg-[#1f2833]/30 backdrop-blur-md">
        <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <div class="flex items-center space-x-2">
                <span class="text-2xl font-black tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-purple-500 to-pink-500 neon-text">
                    NEXUS ESPORTS
                </span>
            </div>
            <a href="index.php" class="text-sm text-gray-400 hover:text-white transition-colors duration-200">
                &larr; กลับหน้าล็อกอิน
            </a>
        </div>
    </header>

    <!-- Main Registration Section -->
    <main class="max-w-md mx-auto px-4 py-12 w-full flex-grow flex items-center">
        <div class="w-full bg-[#1f2833]/60 p-8 rounded-2xl border border-pink-900/30 neon-border backdrop-blur-sm">
            <h2 class="text-2xl font-bold text-white mb-2 tracking-wide text-center uppercase">
                ลงทะเบียน <span class="text-pink-500">สมัครเข้าสังกัด</span>
            </h2>
            <p class="text-xs text-gray-400 text-center mb-6">กรอกข้อมูลผู้สมัครเพื่อรับสิทธิ์เข้าร่วมการทดสอบปฏิกิริยาสายตาและปุ่มสัมผัส</p>

            <?php if (!empty($success_message)): ?>
                <div class="mb-6 p-4 bg-emerald-950/50 border border-emerald-500 text-emerald-200 text-sm rounded text-center">
                    <p class="font-bold mb-1">🎉 <?php echo htmlspecialchars($success_message); ?></p>
                    <p class="text-xs text-emerald-400">ระบบจะทำการเปลี่ยนหน้าภายใน 3 วินาที...</p>
                </div>
                <script>
                    setTimeout(function() {
                        window.location.href = 'index.php';
                    }, 3000);
                </script>
            <?php endif; ?>

            <?php if (!empty($error_message)): ?>
                <div class="mb-6 p-3 bg-red-900/40 border border-red-500 text-red-200 text-sm rounded text-center">
                    <?php echo htmlspecialchars($error_message); ?>
                </div>
            <?php endif; ?>

            <form action="register.php" method="POST" class="space-y-4">
                <!-- ชื่อ-นามสกุล -->
                <div>
                    <label for="name" class="block text-xs font-mono text-gray-400 uppercase tracking-wider mb-1">
                        ชื่อ-นามสกุล (Name-Surname)
                    </label>
                    <input type="text" name="name" id="name" placeholder="นาย แชมเปี้ยน นิวเจเนอเรชั่น" required
                           oninput="generateGamerUsername(this.value)"
                           class="w-full bg-[#0b0c10] border border-purple-900/40 rounded-lg px-4 py-2.5 text-white focus:outline-none focus:border-pink-500 transition-colors">
                </div>

                <!-- อีเมล -->
                <div>
                    <label for="email" class="block text-xs font-mono text-gray-400 uppercase tracking-wider mb-1">
                        อีเมล (Email)
                    </label>
                    <input type="email" name="email" id="email" placeholder="champion@nexus.com" required
                           class="w-full bg-[#0b0c10] border border-purple-900/40 rounded-lg px-4 py-2.5 text-white focus:outline-none focus:border-pink-500 transition-colors">
                </div>

                <!-- เบอร์โทรศัพท์ -->
                <div>
                    <label for="phone" class="block text-xs font-mono text-gray-400 uppercase tracking-wider mb-1">
                        เบอร์โทรศัพท์ (Phone Number)
                    </label>
                    <input type="tel" name="phone" id="phone" placeholder="0891234567" required
                           class="w-full bg-[#0b0c10] border border-purple-900/40 rounded-lg px-4 py-2.5 text-white focus:outline-none focus:border-pink-500 transition-colors">
                </div>

                <!-- Username ที่สุ่มขึ้นมาให้ หรือผู้ใช้กำหนดเองก็ได้ -->
                <div>
                    <div class="flex justify-between items-center mb-1">
                        <label for="username" class="block text-xs font-mono text-gray-400 uppercase tracking-wider">
                            Username สำหรับเข้าสู่ระบบ
                        </label>
                        <button type="button" onclick="triggerRandomUsername()" class="text-[10px] text-pink-400 hover:underline">
                            🔄 สุ่มรหัสใหม่
                        </button>
                    </div>
                    <input type="text" name="username" id="username" placeholder="ตั้งค่าชื่อผู้ใช้สำหรับล็อกอิน" required
                           class="w-full bg-[#0b0c10] border border-pink-500/30 rounded-lg px-4 py-2.5 text-white font-mono focus:outline-none focus:border-pink-500 transition-colors">
                    <p class="text-[10px] text-gray-500 mt-1">💡 ระบบจะสุ่ม Username แนะนำให้เมื่อกรอกชื่อ หรือคุณสามารถตั้งค่าเองได้ตามใจชอบ</p>
                </div>

                <!-- Password -->
                <div>
                    <label for="password" class="block text-xs font-mono text-gray-400 uppercase tracking-wider mb-1">
                        รหัสผ่านสำหรับใช้งาน (Password)
                    </label>
                    <input type="password" name="password" id="password" placeholder="••••••••" required
                           class="w-full bg-[#0b0c10] border border-purple-900/40 rounded-lg px-4 py-2.5 text-white focus:outline-none focus:border-pink-500 transition-colors">
                </div>

                <!-- ปุ่มสมัครสมาชิก -->
                <button type="submit" class="w-full bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-purple-500 text-white font-bold py-3 px-4 rounded-lg transition-all duration-300 neon-btn tracking-wider uppercase mt-4">
                    ส่งข้อมูลใบสมัคร / SIGN UP
                </button>
            </form>
        </div>
    </main>

    <!-- Script สำหรับช่วยสร้าง Username อัจฉริยะ -->
    <script>
        // ฟังก์ชันช่วยเปลี่ยนภาษาอังกฤษง่ายๆ เพื่อนำมาสุ่ม Username
        function generateGamerUsername(fullName) {
            const usernameInput = document.getElementById('username');
            // หากผู้ใช้พิมพ์ไปแล้วและแก้ไขโดยตรง จะไม่ไปเขียนทับแบบอัตโนมัติเว้นแต่ยังว่างอยู่
            if (fullName.trim() !== "" && (usernameInput.value === "" || usernameInput.value.startsWith('NEXUS_') || usernameInput.value.startsWith('PRO_'))) {
                const cleanName = fullName.replace(/[^a-zA-Z]/g, '').toLowerCase().substring(0, 6);
                const randomId = Math.floor(1000 + Math.random() * 9000);
                const prefixList = ['PRO_', 'NEXUS_', 'PLAYER_', 'CYBER_'];
                const selectedPrefix = prefixList[Math.floor(Math.random() * prefixList.length)];
                
                if (cleanName) {
                    usernameInput.value = selectedPrefix + cleanName + "_" + randomId;
                } else {
                    usernameInput.value = selectedPrefix + randomId;
                }
            }
        }

        // ฟังก์ชันปุ่มสุ่มรหัสใหม่ด่วน
        function triggerRandomUsername() {
            const usernameInput = document.getElementById('username');
            const randomId = Math.floor(10000 + Math.random() * 90000);
            const prefixList = ['NXS_PRO_', 'ESPORT_', 'GAMER_', 'AGENT_', 'STRIKER_'];
            const selectedPrefix = prefixList[Math.floor(Math.random() * prefixList.length)];
            usernameInput.value = selectedPrefix + randomId;
        }

        // ตั้งรหัสสุ่มให้ตั้งแต่แรกเริ่มรันหน้าจอ
        window.onload = function() {
            triggerRandomUsername();
        }
    </script>

    <!-- Footer -->
    <footer class="border-t border-purple-900/20 bg-black/40 py-6 text-center text-xs text-gray-500">
        <div class="max-w-7xl mx-auto px-4">
            <p>&copy; 2026 NEXUS ESPORTS CLUB. All Rights Reserved. Selection Server v1.0.4</p>
        </div>
    </footer>

</body>
</html>
