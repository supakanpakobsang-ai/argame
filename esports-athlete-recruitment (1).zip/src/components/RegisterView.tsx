import React, { useState, useEffect } from "react";
import { UserPlus, ArrowLeft, RefreshCw, UserCheck } from "lucide-react";

interface RegisterViewProps {
  onRegisterSuccess: () => void;
  onNavigateToLogin: () => void;
}

export default function RegisterView({ onRegisterSuccess, onNavigateToLogin }: RegisterViewProps) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");
  const [loading, setLoading] = useState(false);

  // Auto generate user on mount
  useEffect(() => {
    triggerRandomUsername();
  }, []);

  const triggerRandomUsername = () => {
    const randomId = Math.floor(10000 + Math.random() * 90000);
    const prefixList = ["NXS_PRO_", "ESPORT_", "GAMER_", "AGENT_", "STRIKER_"];
    const selectedPrefix = prefixList[Math.floor(Math.random() * prefixList.length)];
    setUsername(selectedPrefix + randomId);
  };

  const handleNameChange = (val: string) => {
    setName(val);
    if (val.trim() !== "" && (username === "" || username.startsWith("NEXUS_") || username.startsWith("PRO_") || username.startsWith("PLAYER_"))) {
      const cleanName = val.replace(/[^a-zA-Z]/g, "").toLowerCase().substring(0, 6);
      const randomId = Math.floor(1000 + Math.random() * 9000);
      const prefixList = ["PRO_", "NEXUS_", "PLAYER_"];
      const selectedPrefix = prefixList[Math.floor(Math.random() * prefixList.length)];
      if (cleanName) {
        setUsername(selectedPrefix + cleanName + "_" + randomId);
      } else {
        setUsername(selectedPrefix + randomId);
      }
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setSuccess("");
    setLoading(true);

    try {
      const res = await fetch("/api/register", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ name, email, phone, username, password }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "สมัครสมาชิกสมาชิกล้มเหลว");
      }

      setSuccess("ลงทะเบียนใบสมัครนักกีฬาสำเร็จ! ระบบกำลังนำคุณไปหน้าเข้าสู่ระบบ...");
      setTimeout(() => {
        onRegisterSuccess();
      }, 3000);
    } catch (err: any) {
      setError(err.message || "เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-md mx-auto">
      <div className="bg-zinc-900/50 p-8 border border-white/10 backdrop-blur-sm relative">
        <div className="absolute top-0 right-0 bg-[#00ff9d] text-black px-2 py-0.5 text-[9px] font-mono font-bold uppercase tracking-wider">
          REGISTRATION_NODE
        </div>
        
        {/* หัวเรื่อง */}
        <div className="mb-8">
          <h3 className="text-[10px] font-bold tracking-[0.3em] uppercase text-[#00ff9d] mb-2 font-display">Authentication</h3>
          <h2 className="text-2xl font-black text-white uppercase italic tracking-tight font-display">
            ลงทะเบียน <span className="text-transparent text-stroke-white opacity-80">สมัครเข้าสังกัด</span>
          </h2>
          <p className="text-xs text-zinc-500 mt-1 font-sans">กรอกข้อมูลผู้สมัครเพื่อรับสิทธิ์เข้าร่วมการทดสอบปฏิกิริยาสายตา</p>
        </div>

        {/* ข้อความแจ้งเตือน */}
        {success && (
          <div className="mb-6 p-4 bg-emerald-950/20 border border-emerald-500/50 text-emerald-300 text-xs text-center font-mono font-semibold">
            🎉 {success}
          </div>
        )}

        {error && (
          <div className="mb-6 p-4 bg-red-950/20 border border-red-800/50 text-red-300 text-xs text-center font-mono font-semibold">
            ⚠️ {error}
          </div>
        )}

        <form onSubmit={handleRegister} className="space-y-6">
          {/* ชื่อ-นามสกุล */}
          <div>
            <label htmlFor="reg-name" className="block text-[10px] uppercase tracking-widest text-zinc-500 mb-1 font-mono">
              ชื่อ-นามสกุล (Name-Surname)
            </label>
            <input
              type="text"
              id="reg-name"
              value={name}
              onChange={(e) => handleNameChange(e.target.value)}
              placeholder="นาย แชมเปี้ยน นิวเจเนอเรชั่น"
              required
              className="w-full bg-transparent border-b border-white/20 py-2 text-sm focus:outline-none focus:border-[#00ff9d] placeholder:text-zinc-700 text-white transition-colors"
            />
          </div>

          {/* อีเมล */}
          <div>
            <label htmlFor="reg-email" className="block text-[10px] uppercase tracking-widest text-zinc-500 mb-1 font-mono">
              อีเมล (Email)
            </label>
            <input
              type="email"
              id="reg-email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="champion@nexus.com"
              required
              className="w-full bg-transparent border-b border-white/20 py-2 text-sm focus:outline-none focus:border-[#00ff9d] placeholder:text-zinc-700 text-white transition-colors"
            />
          </div>

          {/* เบอร์โทรศัพท์ */}
          <div>
            <label htmlFor="reg-phone" className="block text-[10px] uppercase tracking-widest text-zinc-500 mb-1 font-mono">
              เบอร์โทรศัพท์ (Phone Number)
            </label>
            <input
              type="tel"
              id="reg-phone"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="0891234567"
              required
              className="w-full bg-transparent border-b border-white/20 py-2 text-sm focus:outline-none focus:border-[#00ff9d] placeholder:text-zinc-700 text-white transition-colors"
            />
          </div>

          {/* Username ที่สุ่มขึ้นมาให้ หรือผู้ใช้กำหนดเองก็ได้ */}
          <div>
            <div className="flex justify-between items-center mb-1">
              <label htmlFor="reg-username" className="block text-[10px] uppercase tracking-widest text-zinc-500 font-mono">
                Username สำหรับเข้าสู่ระบบ
              </label>
              <button
                type="button"
                onClick={triggerRandomUsername}
                className="text-[10px] text-[#00ff9d] hover:underline flex items-center space-x-1 cursor-pointer font-mono font-bold"
              >
                <RefreshCw size={10} />
                <span>สุ่มรหัสใหม่</span>
              </button>
            </div>
            <input
              type="text"
              id="reg-username"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="ตั้งค่าชื่อผู้ใช้สำหรับล็อกอิน"
              required
              className="w-full bg-transparent border-b border-white/20 py-2 text-sm focus:outline-none focus:border-[#00ff9d] placeholder:text-zinc-700 text-white transition-colors font-mono"
            />
            <p className="text-[9px] text-zinc-500 mt-1">💡 ระบบช่วยแนะนำจากชื่อเล่น หรือจะตั้งค่ากำหนดเองก็ได้</p>
          </div>

          {/* Password */}
          <div>
            <label htmlFor="reg-password" className="block text-[10px] uppercase tracking-widest text-zinc-500 mb-1 font-mono">
              รหัสผ่านสำหรับใช้งาน (Password)
            </label>
            <input
              type="password"
              id="reg-password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              required
              className="w-full bg-transparent border-b border-white/20 py-2 text-sm focus:outline-none focus:border-[#00ff9d] placeholder:text-zinc-700 text-white transition-colors"
            />
          </div>

          {/* ปุ่มส่งข้อมูล */}
          <button
            type="submit"
            disabled={loading || success !== ""}
            className="w-full py-4 bg-[#00ff9d] text-black font-black text-xs uppercase tracking-widest hover:bg-white transition-colors cursor-pointer disabled:opacity-55 font-mono"
          >
            {loading ? "RECORDING..." : "SUBMIT REGISTRATION"}
          </button>
        </form>

        <div className="mt-8 pt-4 border-t border-white/10 text-center">
          <button
            onClick={onNavigateToLogin}
            className="text-xs text-zinc-400 hover:text-white flex items-center justify-center space-x-1.5 mx-auto transition-colors cursor-pointer uppercase tracking-widest font-bold"
          >
            <ArrowLeft size={12} />
            <span>ย้อนกลับไปหน้าเข้าสู่ระบบ</span>
          </button>
        </div>

      </div>
    </div>
  );
}
