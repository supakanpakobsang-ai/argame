import React from "react";
import { User } from "../types";
import { Trophy, ShieldAlert, LogOut, Terminal, Play, UserPlus, LogIn } from "lucide-react";

interface NavbarProps {
  currentUser: User | null;
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onLogout: () => void;
}

export default function Navbar({ currentUser, activeTab, setActiveTab, onLogout }: NavbarProps) {
  return (
    <header className="border-b border-white/10 bg-[#050505]/90 backdrop-blur-md sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-6 py-5 flex flex-col md:flex-row justify-between items-center gap-4">
        {/* Brand Logo */}
        <div className="flex items-center space-x-3 cursor-pointer select-none group" onClick={() => setActiveTab("home")}>
          <div className="w-2.5 h-2.5 bg-[#00ff9d] rounded-full animate-pulse"></div>
          <span className="text-xl font-extrabold tracking-[0.35em] text-white font-display uppercase italic group-hover:text-[#00ff9d] transition-colors">
            NEXUS <span className="text-[#00ff9d] text-stroke-white">ESPORTS</span>
          </span>
        </div>

        {/* Tab Navigation */}
        <nav className="flex flex-wrap justify-center gap-2">
          <button
            onClick={() => setActiveTab("home")}
            className={`flex items-center space-x-2 px-4 py-2 border text-xs font-bold uppercase tracking-widest transition-all duration-300 ${
              activeTab === "home"
                ? "bg-white text-black border-white shadow-[0_0_15px_rgba(255,255,255,0.1)]"
                : "text-zinc-400 border-white/10 hover:text-white hover:bg-zinc-900"
            }`}
          >
            <LogIn size={13} />
            <span>หน้าแรก & ล็อกอิน</span>
          </button>

          <button
            onClick={() => setActiveTab("register")}
            className={`flex items-center space-x-2 px-4 py-2 border text-xs font-bold uppercase tracking-widest transition-all duration-300 ${
              activeTab === "register"
                ? "bg-white text-black border-white shadow-[0_0_15px_rgba(255,255,255,0.1)]"
                : "text-zinc-400 border-white/10 hover:text-white hover:bg-zinc-900"
            }`}
          >
            <UserPlus size={13} />
            <span>ลงทะเบียนผู้สมัคร</span>
          </button>

          <button
            onClick={() => {
              if (!currentUser) {
                alert("🔒 กรุณาเข้าสู่ระบบก่อนเข้าเล่นเกมทดสอบ (Session Check)");
                setActiveTab("home");
              } else {
                setActiveTab("game");
              }
            }}
            className={`flex items-center space-x-2 px-4 py-2 border text-xs font-bold uppercase tracking-widest transition-all duration-300 ${
              activeTab === "game"
                ? "bg-[#00ff9d] text-black border-[#00ff9d] shadow-[0_0_15px_rgba(0,255,157,0.2)] font-black"
                : "text-zinc-400 border-white/10 hover:text-white hover:bg-zinc-900"
            }`}
          >
            <Play size={13} className="fill-current" />
            <span>เกมทดสอบ AR (Webcam)</span>
          </button>

          <button
            onClick={() => setActiveTab("code")}
            className={`flex items-center space-x-2 px-4 py-2 border text-xs font-bold uppercase tracking-widest transition-all duration-300 ${
              activeTab === "code"
                ? "bg-zinc-900 text-white border-[#00ff9d] shadow-[0_0_15px_rgba(0,255,157,0.15)]"
                : "text-zinc-400 border-white/10 hover:text-white hover:bg-zinc-900"
            }`}
          >
            <Terminal size={13} />
            <span>ดาวน์โหลดซอร์สโค้ด PHP</span>
          </button>
        </nav>

        {/* User Status */}
        <div className="flex items-center space-x-3 text-xs">
          {currentUser ? (
            <div className="flex items-center space-x-3 bg-zinc-900/60 px-4 py-1.5 rounded-sm border border-white/10">
              <div className="text-right">
                <span className="block text-zinc-500 font-mono text-[9px] tracking-wider">PLAYER IDENTITY</span>
                <span className="text-white font-extrabold text-xs">{currentUser.name}</span>
                <span className="text-[#00ff9d] font-mono font-bold text-xs ml-1.5">({currentUser.username})</span>
              </div>
              <button
                onClick={onLogout}
                title="ออกจากระบบ"
                className="bg-zinc-950 hover:bg-red-950 border border-white/10 hover:border-red-800/50 p-2 text-zinc-400 hover:text-red-400 transition-colors cursor-pointer rounded-sm"
              >
                <LogOut size={13} />
              </button>
            </div>
          ) : (
            <div className="text-[10px] text-[#00ff9d] font-mono tracking-[0.25em] bg-[#00ff9d]/5 px-4 py-2 border border-[#00ff9d]/20 uppercase">
              ⚡ PRO SELECTION ACTIVE
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
