import React, { useState, useEffect, useRef } from "react";
import { User } from "../types";
import { Trophy, Save, ShieldAlert, Video, Gamepad2, Info } from "lucide-react";

interface GameViewProps {
  currentUser: User | null;
  onScoreSaved: (newHighScore: number) => void;
}

export default function GameView({ currentUser, onScoreSaved }: GameViewProps) {
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(currentUser?.high_score || 0);
  const [isMouseMode, setIsMouseMode] = useState(false);
  const [cameraStatus, setCameraStatus] = useState("กำลังเริ่มต้นระบบและกล้องเว็บแคม...");
  const [saveLoading, setSaveLoading] = useState(false);
  const [statusMsg, setStatusMsg] = useState<{ type: "success" | "info" | "error"; text: string } | null>(null);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Game coordinates ref (to avoid re-running useEffect on position states)
  const gameStateRef = useRef({
    score: 0,
    star: { x: 320, y: 240, radius: 25 },
    hand: { x: -100, y: -100, isTracking: false },
    canvasWidth: 640,
    canvasHeight: 480,
  });

  // Keep ref score in sync with react state
  useEffect(() => {
    gameStateRef.current.score = score;
  }, [score]);

  // Sync user's high score
  useEffect(() => {
    if (currentUser) {
      setHighScore(currentUser.high_score);
    }
  }, [currentUser]);

  // Spawn star function
  const spawnStar = (width: number, height: number) => {
    gameStateRef.current.star.x = Math.floor(Math.random() * (width - 100)) + 50;
    gameStateRef.current.star.y = Math.floor(Math.random() * (height - 100)) + 50;
  };

  // Synthesize beep sound
  const playBeep = () => {
    try {
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioCtx.createOscillator();
      const gainNode = audioCtx.createGain();
      
      oscillator.type = "sine";
      oscillator.frequency.setValueAtTime(880, audioCtx.currentTime); // high pitched clean gaming sound
      gainNode.gain.setValueAtTime(0.08, audioCtx.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.1);
      
      oscillator.connect(gainNode);
      gainNode.connect(audioCtx.destination);
      oscillator.start();
      oscillator.stop(audioCtx.currentTime + 0.12);
    } catch (e) {
      // Audio permission or support issue
    }
  };

  // Switch to mouse control
  const enableMouseFallback = () => {
    setIsMouseMode(true);
    setCameraStatus("สลับใช้งานโหมดเมาส์จำลองเป็นกล้องสำรอง");
    spawnStar(640, 480);
  };

  // Save score to database
  const saveScoreToDb = async () => {
    if (!currentUser) return;
    setSaveLoading(true);
    setStatusMsg(null);

    try {
      const token = localStorage.getItem("nexus_token");
      const res = await fetch("/api/save-score", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ score }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "ไม่สามารถบันทึกสถิติได้");
      }

      if (data.isNewHighScore) {
        setHighScore(data.high_score);
        onScoreSaved(data.high_score);
        setStatusMsg({ type: "success", text: `🏆 บันทึกคะแนนใหม่สูงสุดสำเร็จ! สถิติใหม่: ${data.high_score} คะแนน` });
      } else {
        setStatusMsg({ type: "info", text: `ℹ️ ${data.message} (คะแนนรอบนี้: ${score}, สถิติเดิม: ${data.high_score})` });
      }
    } catch (err: any) {
      setStatusMsg({ type: "error", text: `❌ ข้อผิดพลาด: ${err.message}` });
    } finally {
      setSaveLoading(false);
    }
  };

  // Core Game Loop and AI Initializer
  useEffect(() => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let active = true;
    let cameraInstance: any = null;
    let handsInstance: any = null;

    // Helper to draw the star
    const drawStarShape = (
      context: CanvasRenderingContext2D,
      cx: number,
      cy: number,
      spikes: number,
      outerRadius: number,
      innerRadius: number,
      color: string
    ) => {
      let rot = (Math.PI / 2) * 3;
      let x = cx;
      let y = cy;
      const step = Math.PI / spikes;

      context.beginPath();
      context.moveTo(cx, cy - outerRadius);
      for (let i = 0; i < spikes; i++) {
        x = cx + Math.cos(rot) * outerRadius;
        y = cy + Math.sin(rot) * outerRadius;
        context.lineTo(x, y);
        rot += step;

        x = cx + Math.cos(rot) * innerRadius;
        y = cy + Math.sin(rot) * innerRadius;
        context.lineTo(x, y);
        rot += step;
      }
      context.lineTo(cx, cy - outerRadius);
      context.closePath();

      context.fillStyle = color;
      context.fill();
      context.strokeStyle = "#ffffff";
      context.lineWidth = 1.5;
      context.stroke();
    };

    // Collision check helper
    const checkCollision = (x1: number, y1: number, x2: number, y2: number, r1: number, r2: number) => {
      const distance = Math.hypot(x2 - x1, y2 - y1);
      return distance < r1 + r2;
    };

    // Callback on hands results
    const onResults = (results: any) => {
      if (!active || isMouseMode) return;

      // Draw mirrored background video
      ctx.save();
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.translate(canvas.width, 0);
      ctx.scale(-1, 1);
      ctx.drawImage(results.image, 0, 0, canvas.width, canvas.height);
      ctx.restore();

      gameStateRef.current.hand.isTracking = false;

      // Parse hand points
      if (results.multiHandLandmarks && results.multiHandLandmarks.length > 0) {
        const landmarks = results.multiHandLandmarks[0];
        const indexFingerTip = landmarks[8]; // Landmark 8: INDEX_FINGER_TIP

        // Mirror X coordinate since the camera is mirrored
        gameStateRef.current.hand.x = (1 - indexFingerTip.x) * canvas.width;
        gameStateRef.current.hand.y = indexFingerTip.y * canvas.height;
        gameStateRef.current.hand.isTracking = true;
      }

      const { star, hand } = gameStateRef.current;

      // Draw Star Target
      drawStarShape(ctx, star.x, star.y, 5, star.radius, star.radius / 2.2, "#00ff9d");

      // Draw tracked hand pointer
      if (hand.isTracking) {
        // Neon tracking cursor
        ctx.beginPath();
        ctx.arc(hand.x, hand.y, 14, 0, 2 * Math.PI);
        ctx.fillStyle = "rgba(255, 255, 255, 0.85)";
        ctx.fill();

        ctx.beginPath();
        ctx.arc(hand.x, hand.y, 25, 0, 2 * Math.PI);
        ctx.strokeStyle = "#00ff9d"; // Neon green tracked status
        ctx.lineWidth = 2.5;
        ctx.stroke();

        // Check intersection
        if (checkCollision(hand.x, hand.y, star.x, star.y, 14, star.radius)) {
          playBeep();
          setScore((prev) => prev + 1);
          spawnStar(canvas.width, canvas.height);
        }
      }
    };

    // Render loop for Mouse fallback mode
    let animationId: number;
    const renderMouseGame = () => {
      if (!active) return;
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Dark space background for grid
      ctx.fillStyle = "#050505";
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Draw gridlines
      ctx.strokeStyle = "rgba(0, 255, 157, 0.06)";
      ctx.lineWidth = 1;
      for (let i = 0; i < canvas.width; i += 40) {
        ctx.beginPath();
        ctx.moveTo(i, 0);
        ctx.lineTo(i, canvas.height);
        ctx.stroke();
      }
      for (let j = 0; j < canvas.height; j += 40) {
        ctx.beginPath();
        ctx.moveTo(0, j);
        ctx.lineTo(canvas.width, j);
        ctx.stroke();
      }

      const { star, hand } = gameStateRef.current;

      // Draw Star Target
      drawStarShape(ctx, star.x, star.y, 5, star.radius, star.radius / 2.2, "#00ff9d");

      // Draw Mouse Cursor simulated pointer
      if (hand.isTracking) {
        ctx.beginPath();
        ctx.arc(hand.x, hand.y, 12, 0, 2 * Math.PI);
        ctx.fillStyle = "rgba(255, 255, 255, 0.85)"; // White pointer
        ctx.fill();

        ctx.beginPath();
        ctx.arc(hand.x, hand.y, 22, 0, 2 * Math.PI);
        ctx.strokeStyle = "#00ff9d"; // Neon Green
        ctx.lineWidth = 2;
        ctx.stroke();

        if (checkCollision(hand.x, hand.y, star.x, star.y, 12, star.radius)) {
          playBeep();
          setScore((prev) => prev + 1);
          spawnStar(canvas.width, canvas.height);
        }
      }

      animationId = requestAnimationFrame(renderMouseGame);
    };

    // Initialize MediaPipe if NOT in Mouse Mode
    if (!isMouseMode) {
      const { Hands, Camera } = window as any;

      if (Hands && Camera) {
        try {
          handsInstance = new Hands({
            locateFile: (file: string) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`,
          });

          handsInstance.setOptions({
            maxNumHands: 1,
            modelComplexity: 1,
            minDetectionConfidence: 0.6,
            minTrackingConfidence: 0.6,
          });

          handsInstance.onResults(onResults);

          cameraInstance = new Camera(video, {
            onFrame: async () => {
              if (active && !isMouseMode) {
                await handsInstance.send({ image: video });
              }
            },
            width: 640,
            height: 480,
          });

          cameraInstance.start()
            .then(() => {
              setCameraStatus("🟢 ทำงานสมบูรณ์ (โหมดวิเคราะห์ขยับมือเปิดใช้งาน)");
              spawnStar(640, 480);
            })
            .catch((err: any) => {
              console.warn("Camera access failed, fallback to mouse:", err);
              enableMouseFallback();
            });

        } catch (err) {
          console.error("MediaPipe initialization error:", err);
          enableMouseFallback();
        }
      } else {
        // CDNs not loaded, default to mouse
        enableMouseFallback();
      }
    } else {
      // Start Mouse Mode loop
      renderMouseGame();
    }

    // Canvas Mouse Listeners for fallback
    const handleMouseMove = (e: MouseEvent) => {
      if (!isMouseMode) return;
      const rect = canvas.getBoundingClientRect();
      gameStateRef.current.hand.x = (e.clientX - rect.left) * (canvas.width / rect.width);
      gameStateRef.current.hand.y = (e.clientY - rect.top) * (canvas.height / rect.height);
      gameStateRef.current.hand.isTracking = true;
    };

    const handleMouseLeave = () => {
      if (!isMouseMode) return;
      gameStateRef.current.hand.isTracking = false;
    };

    canvas.addEventListener("mousemove", handleMouseMove);
    canvas.addEventListener("mouseleave", handleMouseLeave);

    return () => {
      active = false;
      canvas.removeEventListener("mousemove", handleMouseMove);
      canvas.removeEventListener("mouseleave", handleMouseLeave);
      if (cameraInstance) {
        cameraInstance.stop?.();
      }
      if (handsInstance) {
        handsInstance.close?.();
      }
      cancelAnimationFrame(animationId);
    };
  }, [isMouseMode]);

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 w-full">
      {/* แผงคะแนนและการควบคุมด้านซ้าย */}
      <div className="lg:col-span-4 space-y-6">
        <div className="bg-zinc-900/50 p-6 border border-white/10 shadow-xl backdrop-blur-sm relative">
          <div className="absolute top-0 right-0 bg-white/10 text-white px-2 py-0.5 text-[8px] font-mono uppercase tracking-wider">
            STATS_NODE
          </div>
          <div className="flex items-center space-x-2 border-b border-white/10 pb-3 mb-4">
            <Gamepad2 className="text-[#00ff9d]" size={18} />
            <h3 className="text-xs font-bold tracking-[0.25em] text-white uppercase font-display">แผงวัดผลปฏิกิริยา</h3>
          </div>

          <div className="space-y-4">
            {/* คะแนนปัจจุบัน */}
            <div className="p-5 bg-black/40 border border-white/5 text-center relative overflow-hidden">
              <div className="text-[10px] text-zinc-500 font-mono uppercase tracking-wider">คะแนนรอบปัจจุบัน (Score)</div>
              <div className="text-5xl font-black text-[#00ff9d] font-mono mt-2 drop-shadow-[0_0_15px_rgba(0,255,157,0.3)]">
                {score}
              </div>
            </div>

            {/* คะแนนสูงสุดส่วนบุคคล */}
            <div className="p-5 bg-black/40 border border-white/5 text-center">
              <div className="text-[10px] text-zinc-500 font-mono uppercase tracking-wider">สถิติสูงสุด (Personal Best)</div>
              <div className="text-3xl font-black text-white font-mono mt-2 flex items-center justify-center space-x-2">
                <Trophy size={18} className="text-[#00ff9d]" />
                <span>{highScore} PTS</span>
              </div>
            </div>

            {/* คำอธิบายกติกา */}
            <div className="p-5 bg-zinc-950/40 border border-white/10 space-y-3 text-xs text-zinc-400">
              <div className="flex items-center space-x-2 text-[#00ff9d] font-bold uppercase tracking-wider font-mono">
                <Info size={14} />
                <span>คำแนะนำการเล่น:</span>
              </div>
              <ul className="list-disc list-inside space-y-2 text-[11px] leading-relaxed">
                <li>เปิดสิทธิ์ให้เบราว์เซอร์เข้าถึงเว็บแคมเพื่อเริ่มวิเคราะห์</li>
                <li>ชูมือแล้วขยับ <span className="text-[#00ff9d] font-bold">ปลายนิ้วชี้</span> แตะ <span className="text-white underline">เป้าดวงดาวสีเขียว</span></li>
                <li>หากอุปกรณ์ขัดข้อง สามารถกดสลับเล่นผ่านเมาส์แทนได้</li>
                <li>สะสมคะแนนให้สูงที่สุดแล้วกดปุ่มบันทึกคะแนนเข้าสู่ระบบด้านล่าง</li>
              </ul>
            </div>
          </div>
        </div>

        {/* ปุ่มบันทึกคะแนน */}
        <div className="bg-zinc-900/50 p-6 border border-white/10 shadow-md backdrop-blur-sm space-y-4 relative">
          <div className="absolute top-0 right-0 bg-[#00ff9d]/10 text-[#00ff9d] px-2 py-0.5 text-[8px] font-mono uppercase tracking-wider">
            SYNC_NODE
          </div>
          <button
            onClick={saveScoreToDb}
            disabled={saveLoading || score === 0}
            className="w-full py-4 bg-[#00ff9d] text-black font-black text-xs uppercase tracking-widest hover:bg-white transition-colors cursor-pointer disabled:opacity-55 font-mono"
          >
            {saveLoading ? "CONNECTING..." : "SAVE SCORE TO SERVER"}
          </button>

          {score === 0 && (
            <p className="text-[10px] text-zinc-500 text-center font-mono">💡 MUST SCORE HIGHER THAN 0 TO SAVE</p>
          )}

          {statusMsg && (
            <div className={`p-3 border text-xs text-center font-mono font-bold uppercase tracking-wider ${
              statusMsg.type === "success" 
                ? "bg-[#00ff9d]/5 border-[#00ff9d]/30 text-[#00ff9d]"
                : statusMsg.type === "info"
                ? "bg-zinc-900 border-white/20 text-white"
                : "bg-red-950/20 border-red-500/50 text-red-300"
            }`}>
              {statusMsg.text}
            </div>
          )}
        </div>
      </div>

      {/* หน้าจอแสดงผลกล้อง AR / คอนโซลเกมหลัก */}
      <div className="lg:col-span-8 flex flex-col space-y-4">
        <div className="relative w-full aspect-video bg-black overflow-hidden border border-white/10 shadow-2xl flex items-center justify-center group">
          {/* วิดีโอเว็บแคมดึงเฟรม */}
          <video
            ref={videoRef}
            id="webcam"
            autoPlay
            playsInline
            muted
            width="640"
            height="480"
            className="hidden"
          ></video>

          {/* แคนวาสเล่นหลัก */}
          <canvas
            ref={canvasRef}
            id="gameCanvas"
            width="640"
            height="480"
            className="w-full h-full object-cover"
          ></canvas>

          {/* ตราประดับโหมดเมาส์สำรอง */}
          {isMouseMode && (
            <div className="absolute top-4 right-4 bg-[#00ff9d] text-black text-[9px] font-bold px-3 py-1 uppercase tracking-widest shadow-lg flex items-center space-x-1.5 font-mono">
              <span className="w-1.5 h-1.5 bg-black rounded-full animate-ping"></span>
              <span>MOUSE_MODE_ACTIVE</span>
            </div>
          )}

          {/* หน้าต่าง Overlay สำหรับกรณีดาวน์โหลดสมองกล (MediaPipe) และเปิดกล้องครั้งแรก */}
          {!isMouseMode && cameraStatus.includes("กำลังเริ่มต้น") && (
            <div className="absolute inset-0 bg-black/95 flex flex-col items-center justify-center text-center p-8 space-y-6">
              <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-[#00ff9d] editorial-glow-strong"></div>
              <div className="text-xs font-semibold text-zinc-300 max-w-sm leading-relaxed uppercase tracking-wider font-mono">
                INITIALIZING AR ENGINE & WEBCAM INTERACTION SYSTEM (MEDIAPIPE AI)...
              </div>
              <button
                onClick={enableMouseFallback}
                className="px-6 py-3 border border-white/20 text-white font-bold text-xs tracking-widest uppercase hover:bg-white/10 transition-colors cursor-pointer"
              >
                START WITH MOUSE CONTROLS (FALLBACK)
              </button>
            </div>
          )}
        </div>

        {/* แถบรายงานสถานะอุปกรณ์คัดกรอง */}
        <div className="flex justify-between items-center bg-zinc-900/30 px-5 py-4 border border-white/10 text-xs">
          <div className="flex items-center space-x-2">
            <Video size={14} className="text-[#00ff9d]" />
            <span className="text-zinc-400">
              อุปกรณ์ตรวจวัด: <span className="text-[#00ff9d] font-bold font-mono">{cameraStatus}</span>
            </span>
          </div>

          {!isMouseMode && (
            <button
              onClick={enableMouseFallback}
              className="text-[10px] text-[#00ff9d] hover:text-white font-bold tracking-widest uppercase cursor-pointer"
            >
              สลับเป็นโหมดจำลองด้วยเมาส์
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
