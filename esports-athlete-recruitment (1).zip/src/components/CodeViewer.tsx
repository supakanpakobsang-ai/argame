import React, { useState } from "react";
import { Terminal, Copy, Check, Download, BookOpen, AlertCircle, Database } from "lucide-react";

export default function CodeViewer() {
  const [copiedFile, setCopiedFile] = useState<string | null>(null);
  const [activeFile, setActiveFile] = useState("db.config.php");

  // คลังไฟล์ PHP ที่เขียนขึ้นตรงตามสเปคของ User
  const phpFiles: Record<string, { desc: string; code: string; lang: string }> = {
    "db.config.php": {
      desc: "ไฟล์เชื่อมต่อฐานข้อมูล MySQL ด้วย PDO สำหรับสตรีมข้อมูลเข้า phpMyAdmin ใน AppServ",
      lang: "php",
      code: `<?php
// db.config.php
// ไฟล์สำหรับเชื่อมต่อฐานข้อมูล MySQL (รองรับการใช้งานบน AppServ / phpMyAdmin)

$host = 'localhost';
$dbname = 'esports_db';
$db_user = 'root';
$db_pass = ''; // รหัสผ่านของ MySQL (ค่าเริ่มต้นของ AppServ มักเป็นค่าว่าง หรือตามที่ตั้งตอนติดตั้ง เช่น 1234)

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $db_user, $db_pass);
    // ตั้งค่าให้แสดง Error Mode เป็น Exception
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("เชื่อมต่อฐานข้อมูลล้มเหลว: " . $e->getMessage());
}
?>`
    },
    "schema.sql": {
      desc: "สคริปต์ SQL สำหรับสร้างฐานข้อมูล esports_db และตาราง users สำหรับรันในเมนู SQL ของ phpMyAdmin",
      lang: "sql",
      code: `-- schema.sql
-- คำสั่งสำหรับสร้างฐานข้อมูลและตารางสำหรับระบบรับสมัครนักกีฬาอีสปอร์ต
-- สามารถนำรหัสนี้ไปรันในเมนู SQL ของ phpMyAdmin ใน AppServ ได้เลยครับ

-- 1. สร้างฐานข้อมูล (ถ้ายังไม่มี)
CREATE DATABASE IF NOT EXISTS \`esports_db\` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE \`esports_db\`;

-- 2. สร้างตาราง users เก็บข้อมูลผู้สมัครและคะแนนสูงสุด
CREATE TABLE IF NOT EXISTS \`users\` (
    \`id\` INT AUTO_INCREMENT PRIMARY KEY,
    \`username\` VARCHAR(50) NOT NULL UNIQUE,
    \`password\` VARCHAR(255) NOT NULL, -- เก็บ password ที่ผ่านการทำ password_hash()
    \`name\` VARCHAR(100) NOT NULL,
    \`email\` VARCHAR(100) NOT NULL UNIQUE,
    \`phone\` VARCHAR(20) NOT NULL,
    \`high_score\` INT DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;`
    },
    "index.php": {
      desc: "หน้าหลักและระบบล็อกอิน (index.php) ประกอบด้วยข้อมูลโครงการสมัคร และฟอร์มรับ Username/Password",
      lang: "php",
      code: `<?php
// index.php
// หน้าหลักและล็อกอินสำหรับระบบสมัครนักกีฬาอีสปอร์ต

session_start();
require_once 'db.config.php';

// หากล็อกอินอยู่แล้ว ส่งไปหน้าเกม
if (isset($_SESSION['user_id'])) {
    header("Location: game.php");
    exit();
}

$error = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if (!empty($username) && !empty($password)) {
        try {
            $stmt = $pdo->prepare("SELECT * FROM users WHERE username = :username");
            $stmt->execute(['username' => $username]);
            $user = $stmt->fetch();

            // ตรวจสอบรหัสผ่านโดยใช้ password_verify กับรหัสที่เข้ารหัสไว้ในฐานข้อมูล
            if ($user && password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['username'] = $user['username'];
                $_SESSION['name'] = $user['name'];
                $_SESSION['high_score'] = $user['high_score'];
                
                header("Location: game.php");
                exit();
            } else {
                $error = "Username หรือ Password ไม่ถูกต้อง!";
            }
        } catch (PDOException $e) {
            $error = "เกิดข้อผิดพลาดในการเชื่อมต่อ: " . $e->getMessage();
        }
    } else {
        $error = "กรุณากรอกข้อมูลให้ครบถ้วน!";
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ESPORTS RECRUITMENT | ประตูสู่วงการอีสปอร์ตระดับโลก</title>
    <!-- ใช้ Tailwind CSS CDN สำหรับการดีไซน์แนวเกมมิ่งที่สวยงาม -->
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .neon-border {
            box-shadow: 0 0 15px rgba(168, 85, 247, 0.4), 0 0 5px rgba(168, 85, 247, 0.2);
        }
        .neon-text {
            text-shadow: 0 0 10px rgba(168, 85, 247, 0.6);
        }
        .neon-btn:hover {
            box-shadow: 0 0 20px rgba(168, 85, 247, 0.8);
            transition: all 0.3s ease;
        }
    </style>
</head>
<body class="bg-[#0b0c10] text-[#c5c6c7] font-sans min-h-screen flex flex-col justify-between">

    <!-- Header / Navigation -->
    <header class="border-b border-purple-900/40 bg-[#1f2833]/30 backdrop-blur-md">
        <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <div class="flex items-center space-x-2">
                <span class="text-2xl font-black tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-purple-500 to-pink-500 neon-text">
                    NEXUS ESPORTS
                </span>
            </div>
            <div class="text-xs text-purple-400 font-mono tracking-wider bg-purple-950/40 px-3 py-1.5 rounded-full border border-purple-800/50">
                PRO SELECTION ROUND
            </div>
        </div>
    </header>

    <!-- Main Content Grid -->
    <main class="max-w-7xl mx-auto px-4 py-12 flex-grow grid grid-cols-1 lg:grid-cols-2 gap-12 items-center w-full">
        
        <!-- ข้อมูลแนะนำโครงการ / มโนเนื้อหา -->
        <div class="space-y-6">
            <div class="inline-block bg-purple-950/50 text-purple-400 border border-purple-800/60 px-4 py-1.5 rounded text-xs font-bold tracking-wider uppercase">
                Now Recruiting 2026
            </div>
            <h1 class="text-4xl md:text-5xl lg:text-6xl font-extrabold text-white tracking-tight leading-none">
                ก้าวข้ามขีดจำกัด<br>
                <span class="text-transparent bg-clip-text bg-gradient-to-r from-purple-400 to-pink-500">
                    สู่นักกีฬาอีสปอร์ตมืออาชีพ
                </span>
            </h1>
            <p class="text-gray-400 leading-relaxed text-base md:text-lg">
                โอกาสทองครั้งสำคัญในการก้าวเข้าสู่ทีม <span class="text-purple-400 font-semibold">NEXUS ESPORTS</span> สังกัดชั้นนำระดับโลก 
                เรากำลังเฟ้นหานักกีฬาหน้าใหม่ที่มีความสามารถเชิงปฏิกิริยาการตอบสนองที่ฉับไว แม่นยำ และมีความตั้งใจจริง
            </p>
            
            <div class="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4">
                <div class="p-4 rounded-lg bg-[#1f2833]/40 border border-purple-900/30">
                    <div class="text-2xl font-bold text-white text-purple-400">100K+ USD</div>
                    <div class="text-xs text-gray-500 mt-1">เงินรางวัลและสัญญาอาชีพ</div>
                </div>
                <div class="p-4 rounded-lg bg-[#1f2833]/40 border border-purple-900/30">
                    <div class="text-2xl font-bold text-white text-pink-400">AR TRAINING</div>
                    <div class="text-xs text-gray-500 mt-1">ทดสอบปฏิกิริยาด้วยมือเปล่า</div>
                </div>
                <div class="p-4 rounded-lg bg-[#1f2833]/40 border border-purple-900/30">
                    <div class="text-2xl font-bold text-white text-purple-400">GLOBAL TEAM</div>
                    <div class="text-xs text-gray-500 mt-1">การสนับสนุนระดับสากล</div>
                </div>
            </div>

            <div class="p-4 rounded-lg bg-yellow-500/10 border border-yellow-500/20 text-yellow-500 text-sm">
                💡 <strong>ขั้นตอนการทดสอบคัดเลือก:</strong> สมัครสมาชิก > เข้าสู่ระบบ > ทำการทดสอบผ่านกล้อง Webcam ในด่าน AR Hand Tracker > บันทึกคะแนนสถิติสูงสุดเพื่อติดอันดับผู้นำ (Leaderboard)
            </div>
        </div>

        <!-- ฟอร์มล็อกอิน -->
        <div class="w-full max-w-md mx-auto bg-[#1f2833]/60 p-8 rounded-2xl border border-purple-900/30 neon-border backdrop-blur-sm">
            <h2 class="text-2xl font-bold text-white mb-6 tracking-wide text-center uppercase">
                <span class="text-purple-500">PLAYER</span> LOGIN
            </h2>

            <?php if (!empty($error)): ?>
                <div class="mb-4 p-3 bg-red-900/40 border border-red-500 text-red-200 text-sm rounded text-center">
                    <?php echo htmlspecialchars($error); ?>
                </div>
            <?php endif; ?>

            <form action="index.php" method="POST" class="space-y-4">
                <div>
                    <label for="username" class="block text-xs font-mono text-gray-400 uppercase tracking-widest mb-1.5">
                        Username (ชื่อผู้ใช้)
                    </label>
                    <input type="text" name="username" id="username" placeholder="ระบุผู้ใช้ของคุณ" required
                           class="w-full bg-[#0b0c10] border border-purple-900/40 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-purple-500 transition-colors">
                </div>

                <div>
                    <label for="password" class="block text-xs font-mono text-gray-400 uppercase tracking-widest mb-1.5">
                        Password (รหัสผ่าน)
                    </label>
                    <input type="password" name="password" id="password" placeholder="••••••••" required
                           class="w-full bg-[#0b0c10] border border-purple-900/40 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-purple-500 transition-colors">
                </div>

                <button type="submit" class="w-full bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-500 hover:to-pink-500 text-white font-bold py-3 px-4 rounded-lg transition-all duration-300 neon-btn tracking-wider uppercase mt-2">
                    เข้าสู่ระบบ / LOG IN
                </button>
            </form>

            <div class="mt-6 pt-6 border-t border-purple-900/20 text-center space-y-3">
                <p class="text-sm text-gray-400">ยังไม่มีไอดีผู้ใช้ในสังกัดของเรา?</p>
                <a href="register.php" class="inline-block w-full bg-transparent hover:bg-purple-950/30 text-purple-400 hover:text-white border border-purple-500/50 hover:border-purple-500 font-bold py-2.5 px-4 rounded-lg transition-all duration-300 text-center tracking-wider uppercase">
                    ลงทะเบียนผู้สมัคร (Register)
                </a>
            </div>
        </div>

    </main>

    <!-- Footer -->
    <footer class="border-t border-purple-900/20 bg-black/40 py-6 text-center text-xs text-gray-500">
        <div class="max-w-7xl mx-auto px-4">
            <p>&copy; 2026 NEXUS ESPORTS CLUB. All Rights Reserved. Selection Server v1.0.4</p>
        </div>
    </footer>

</body>
</html>`
    },
    "register.php": {
      desc: "หน้าลงทะเบียนผู้สมัคร (register.php) สำหรับกรอกประวัติ และรับ Username แนะนำเพื่อเข้าเล่นด่านทดสอบ",
      lang: "php",
      code: `<?php
// register.php
// หน้าลงทะเบียนสมัครสมาชิกสำหรับผู้เข้าร่วมคัดเลือกนักกีฬาอีสปอร์ต

session_start();
require_once 'db.config.php';

$success_message = "";
$error_message = "";
$generated_username = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    if (!empty($name) && !empty($email) && !empty($phone) && !empty($username) && !empty($password)) {
        try {
            // ตรวจสอบข้อมูลซ้ำ
            $check_stmt = $pdo->prepare("SELECT id FROM users WHERE username = :username OR email = :email");
            $check_stmt->execute(['username' => $username, 'email' => $email]);
            
            if ($check_stmt->rowCount() > 0) {
                $error_message = "Username หรือ Email นี้ถูกลงทะเบียนไว้แล้วในระบบ!";
            } else {
                // เข้ารหัสผ่านด้วยฟังก์ชัน password_hash() ตามที่โจทย์ระบุ
                $password_hashed = password_hash($password, PASSWORD_BCRYPT);

                $insert_stmt = $pdo->prepare("INSERT INTO users (username, password, name, email, phone, high_score) VALUES (:username, :password, :name, :email, :phone, 0)");
                $insert_stmt->execute([
                    'username' => $username,
                    'password' => $password_hashed,
                    'name' => $name,
                    'email' => $email,
                    'phone' => $phone
                ]);

                // แสดงข้อความความสำเร็จและเตรียมรีไดเร็กต์
                $success_message = "ลงทะเบียนสมัครสมาชิกสำเร็จ! กำลังพากลับไปหน้าเข้าสู่ระบบ...";
            }
        } catch (PDOException $e) {
            $error_message = "เกิดข้อผิดพลาดในการบันทึกข้อมูล: " . $e->getMessage();
        }
    } else {
        $error_message = "กรุณากรอกข้อมูลให้ครบถ้วนในทุกช่อง!";
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>REGISTER | ลงทะเบียนนักกีฬาอีสปอร์ต</title>
    <!-- ใช้ Tailwind CSS CDN สำหรับการดีไซน์แนวเกมมิ่ง -->
    <script src="https://cdn.tailwindcss.com"></script>
    <style>
        .neon-border {
            box-shadow: 0 0 15px rgba(236, 72, 153, 0.4), 0 0 5px rgba(236, 72, 153, 0.2);
        }
        .neon-text {
            text-shadow: 0 0 10px rgba(236, 72, 153, 0.6);
        }
        .neon-btn:hover {
            box-shadow: 0 0 20px rgba(236, 72, 153, 0.8);
            transition: all 0.3s ease;
        }
    </style>
</head>
<body class="bg-[#0b0c10] text-[#c5c6c7] font-sans min-h-screen flex flex-col justify-between">

    <!-- Header / Navigation -->
    <header class="border-b border-pink-900/40 bg-[#1f2833]/30 backdrop-blur-md">
        <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <div class="flex items-center space-x-2">
                <span class="text-2xl font-black tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-purple-500 to-pink-500 neon-text">
                    NEXUS ESPORTS
                </span>
            </div>
            <a href="index.php" class="text-sm text-gray-400 hover:text-white transition-colors duration-200">
                &larr; กลับหน้าล็อกอิน
            </a>
        </div>
    </header>

    <!-- Main Registration Section -->
    <main class="max-w-md mx-auto px-4 py-12 w-full flex-grow flex items-center">
        <div class="w-full bg-[#1f2833]/60 p-8 rounded-2xl border border-pink-900/30 neon-border backdrop-blur-sm">
            <h2 class="text-2xl font-bold text-white mb-2 tracking-wide text-center uppercase">
                ลงทะเบียน <span class="text-pink-500">สมัครเข้าสังกัด</span>
            </h2>
            <p class="text-xs text-gray-400 text-center mb-6">กรอกข้อมูลผู้สมัครเพื่อรับสิทธิ์เข้าร่วมการทดสอบปฏิกิริยาสายตาและปุ่มสัมผัส</p>

            <?php if (!empty($success_message)): ?>
                <div class="mb-6 p-4 bg-emerald-950/50 border border-emerald-500 text-emerald-200 text-sm rounded text-center">
                    <p class="font-bold mb-1">🎉 <?php echo htmlspecialchars($success_message); ?></p>
                    <p class="text-xs text-emerald-400">ระบบจะทำการเปลี่ยนหน้าภายใน 3 วินาที...</p>
                </div>
                <script>
                    setTimeout(function() {
                        window.location.href = 'index.php';
                    }, 3000);
                </script>
            <?php endif; ?>

            <?php if (!empty($error_message)): ?>
                <div class="mb-6 p-3 bg-red-900/40 border border-red-500 text-red-200 text-sm rounded text-center">
                    <?php echo htmlspecialchars($error_message); ?>
                </div>
            <?php endif; ?>

            <form action="register.php" method="POST" class="space-y-4">
                <!-- ชื่อ-นามสกุล -->
                <div>
                    <label for="name" class="block text-xs font-mono text-gray-400 uppercase tracking-wider mb-1">
                        ชื่อ-นามสกุล (Name-Surname)
                    </label>
                    <input type="text" name="name" id="name" placeholder="นาย แชมเปี้ยน นิวเจเนอเรชั่น" required
                           oninput="generateGamerUsername(this.value)"
                           class="w-full bg-[#0b0c10] border border-purple-900/40 rounded-lg px-4 py-2.5 text-white focus:outline-none focus:border-pink-500 transition-colors">
                </div>

                <!-- อีเมล -->
                <div>
                    <label for="email" class="block text-xs font-mono text-gray-400 uppercase tracking-wider mb-1">
                        อีเมล (Email)
                    </label>
                    <input type="email" name="email" id="email" placeholder="champion@nexus.com" required
                           class="w-full bg-[#0b0c10] border border-purple-900/40 rounded-lg px-4 py-2.5 text-white focus:outline-none focus:border-pink-500 transition-colors">
                </div>

                <!-- เบอร์โทรศัพท์ -->
                <div>
                    <label for="phone" class="block text-xs font-mono text-gray-400 uppercase tracking-wider mb-1">
                        เบอร์โทรศัพท์ (Phone Number)
                    </label>
                    <input type="tel" name="phone" id="phone" placeholder="0891234567" required
                           class="w-full bg-[#0b0c10] border border-purple-900/40 rounded-lg px-4 py-2.5 text-white focus:outline-none focus:border-pink-500 transition-colors">
                </div>

                <!-- Username ที่สุ่มขึ้นมาให้ หรือผู้ใช้กำหนดเองก็ได้ -->
                <div>
                    <div class="flex justify-between items-center mb-1">
                        <label for="username" class="block text-xs font-mono text-gray-400 uppercase tracking-wider">
                            Username สำหรับเข้าสู่ระบบ
                        </label>
                        <button type="button" onclick="triggerRandomUsername()" class="text-[10px] text-pink-400 hover:underline">
                            🔄 สุ่มรหัสใหม่
                        </button>
                    </div>
                    <input type="text" name="username" id="username" placeholder="ตั้งค่าชื่อผู้ใช้สำหรับล็อกอิน" required
                           class="w-full bg-[#0b0c10] border border-pink-500/30 rounded-lg px-4 py-2.5 text-white font-mono focus:outline-none focus:border-pink-500 transition-colors">
                    <p class="text-[10px] text-gray-500 mt-1">💡 ระบบจะสุ่ม Username แนะนำให้เมื่อกรอกชื่อ หรือคุณสามารถตั้งค่าเองได้ตามใจชอบ</p>
                </div>

                <!-- Password -->
                <div>
                    <label for="password" class="block text-xs font-mono text-gray-400 uppercase tracking-wider mb-1">
                        รหัสผ่านสำหรับใช้งาน (Password)
                    </label>
                    <input type="password" name="password" id="password" placeholder="••••••••" required
                           class="w-full bg-[#0b0c10] border border-purple-900/40 rounded-lg px-4 py-2.5 text-white focus:outline-none focus:border-pink-500 transition-colors">
                </div>

                <!-- ปุ่มสมัครสมาชิก -->
                <button type="submit" class="w-full bg-gradient-to-r from-pink-600 to-purple-600 hover:from-pink-500 hover:to-pink-500 text-white font-bold py-3 px-4 rounded-lg transition-all duration-300 neon-btn tracking-wider uppercase mt-4">
                    ส่งข้อมูลใบสมัคร / SIGN UP
                </button>
            </form>
        </div>
    </main>

    <!-- Script สำหรับช่วยสร้าง Username อัจฉริยะ -->
    <script>
        // ฟังก์ชันช่วยเปลี่ยนภาษาอังกฤษง่ายๆ เพื่อนำมาสุ่ม Username
        function generateGamerUsername(fullName) {
            const usernameInput = document.getElementById('username');
            // หากผู้ใช้พิมพ์ไปแล้วและแก้ไขโดยตรง จะไม่ไปเขียนทับแบบอัตโนมัติเว้นแต่ยังว่างอยู่
            if (fullName.trim() !== "" && (usernameInput.value === "" || usernameInput.value.startsWith('NEXUS_') || usernameInput.value.startsWith('PRO_'))) {
                const cleanName = fullName.replace(/[^a-zA-Z]/g, '').toLowerCase().substring(0, 6);
                const randomId = Math.floor(1000 + Math.random() * 9000);
                const prefixList = ['PRO_', 'NEXUS_', 'PLAYER_', 'CYBER_'];
                const selectedPrefix = prefixList[Math.floor(Math.random() * prefixList.length)];
                
                if (cleanName) {
                    usernameInput.value = selectedPrefix + cleanName + "_" + randomId;
                } else {
                    usernameInput.value = selectedPrefix + randomId;
                }
            }
        }

        // ฟังก์ชันปุ่มสุ่มรหัสใหม่ด่วน
        function triggerRandomUsername() {
            const usernameInput = document.getElementById('username');
            const randomId = Math.floor(10000 + Math.random() * 90000);
            const prefixList = ['NXS_PRO_', 'ESPORT_', 'GAMER_', 'AGENT_', 'STRIKER_'];
            const selectedPrefix = prefixList[Math.floor(Math.random() * prefixList.length)];
            usernameInput.value = selectedPrefix + randomId;
        }

        // ตั้งรหัสสุ่มให้ตั้งแต่แรกเริ่มรันหน้าจอ
        window.onload = function() {
            triggerRandomUsername();
        }
    </script>

    <!-- Footer -->
    <footer class="border-t border-purple-900/20 bg-black/40 py-6 text-center text-xs text-gray-500">
        <div class="max-w-7xl mx-auto px-4">
            <p>&copy; 2026 NEXUS ESPORTS CLUB. All Rights Reserved. Selection Server v1.0.4</p>
        </div>
    </footer>

</body>
</html>`
    },
    "game.php": {
      desc: "หน้าเกมทดสอบปฏิกิริยา (game.php) รองรับการตรวจจับความเคลื่อนไหวผ่าน Webcam ดึงโมเดล MediaPipe Hands AI มาคำนวณชนเป้าดาว และอัปเดตสถิติลง MySQL PDO แบบเรียลไทม์",
      lang: "php",
      code: `<?php
// game.php
// หน้าทดสอบปฏิกิริยานักกีฬาอีสปอร์ตด้วยเทคโนโลยี AR จับความเคลื่อนไหวมือ (Webcam)

session_start();

// ด่านป้องกันสิทธิ์: หากผู้ใช้งานยังไม่เคยล็อกอิน ให้เด้งกลับไปหน้าหลักทันที
if (!isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit();
}

require_once 'db.config.php';

// ดึงข้อมูลผู้ใช้งานอัปเดตสุดจากฐานข้อมูล
$userId = $_SESSION['user_id'];
try {
    $stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id");
    $stmt->execute(['id' => $userId]);
    $user = $stmt->fetch();
    if ($user) {
        $_SESSION['high_score'] = $user['high_score'];
    }
} catch (PDOException $e) {
    // ดึงข้อมูลล้มเหลว ใช้คะแนนใน session ไปก่อน
}

// ตรวจสอบส่วนรับข้อมูลบันทึกคะแนนผ่าน AJAX Fetch API (POST Request)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents('php://input'), true);
    
    if (isset($input['score'])) {
        header('Content-Type: application/json');
        $newScore = (int)$input['score'];
        $oldHighScore = (int)$_SESSION['high_score'];
        
        $isUpdated = false;
        if ($newScore > $oldHighScore) {
            try {
                $updateStmt = $pdo->prepare("UPDATE users SET high_score = :score WHERE id = :id");
                $updateStmt->execute(['score' => $newScore, 'id' => $userId]);
                $_SESSION['high_score'] = $newScore;
                $isUpdated = true;
                echo json_encode([
                    'success' => true,
                    'isNewHighScore' => true,
                    'high_score' => $newScore,
                    'message' => 'บันทึกคะแนนสถิติสูงสุดใหม่สำเร็จ!'
                ]);
            } catch (PDOException $e) {
                echo json_encode([
                    'success' => false,
                    'message' => 'ข้อผิดพลาดระบบฐานข้อมูล: ' . $e->getMessage()
                ]);
            }
        } else {
            echo json_encode([
                'success' => true,
                'isNewHighScore' => false,
                'high_score' => $oldHighScore,
                'message' => 'คะแนนไม่เกินสถิติสูงสุดเดิม'
            ]);
        }
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ESPORTS TEST STAGE | ด่านทดสอบความไวปฏิกิริยา AR</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- โหลด MediaPipe CDNs สำหรับการตรวจจับพิกัดมือผ่านกล้องแบบเรียลไทม์ -->
    <script src="https://cdn.jsdelivr.net/npm/@mediapipe/camera_utils/camera_utils.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands.js" crossorigin="anonymous"></script>
    <style>
        .neon-border-purple {
            box-shadow: 0 0 15px rgba(168, 85, 247, 0.4);
        }
        .neon-text-pink {
            text-shadow: 0 0 10px rgba(236, 72, 153, 0.7);
        }
        .neon-text-green {
            text-shadow: 0 0 10px rgba(34, 197, 94, 0.7);
        }
    </style>
</head>
<body class="bg-[#0b0c10] text-[#c5c6c7] font-sans min-h-screen flex flex-col justify-between">

    <!-- Header -->
    <header class="border-b border-purple-900/40 bg-[#1f2833]/30 backdrop-blur-md">
        <div class="max-w-7xl mx-auto px-4 py-4 flex justify-between items-center">
            <span class="text-xl font-black tracking-widest text-transparent bg-clip-text bg-gradient-to-r from-purple-500 to-pink-500">
                NEXUS RECRUITMENT STAGE
            </span>
            <div class="flex items-center space-x-4">
                <div class="text-sm">
                    ยินดีต้อนรับ: <span class="text-purple-400 font-bold"><?php echo htmlspecialchars($_SESSION['name']); ?></span> 
                    (ID: <span class="text-pink-400 font-mono"><?php echo htmlspecialchars($_SESSION['username']); ?></span>)
                </div>
                <a href="logout.php" class="bg-red-950/40 hover:bg-red-900 text-red-300 hover:text-white border border-red-800/60 px-3 py-1.5 rounded text-xs font-bold transition-all duration-200">
                    ออกจากระบบ
                </a>
            </div>
        </div>
    </header>

    <!-- Main Game Section -->
    <main class="max-w-7xl mx-auto px-4 py-8 flex-grow w-full grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        <!-- แผงคะแนนและการควบคุมด้านข้าง -->
        <div class="lg:col-span-1 space-y-6">
            <div class="bg-[#1f2833]/60 p-6 rounded-xl border border-purple-900/30 neon-border-purple">
                <h3 class="text-sm font-mono tracking-widest text-gray-400 uppercase mb-4">ข้อมูลการทดสอบ</h3>
                
                <div class="space-y-4">
                    <div class="p-3 bg-black/40 rounded border border-purple-900/20">
                        <div class="text-xs text-gray-500">คะแนนปัจจุบัน (Current Score)</div>
                        <div class="text-3xl font-black text-green-400 neon-text-green" id="currentScoreDisplay">0</div>
                    </div>

                    <div class="p-3 bg-black/40 rounded border border-purple-900/20">
                        <div class="text-xs text-gray-500">สถิติสูงสุดของคุณ (High Score)</div>
                        <div class="text-2xl font-black text-purple-400" id="personalHighScore">
                            <?php echo (int)$_SESSION['high_score']; ?> คะแนน
                        </div>
                    </div>

                    <div class="text-xs text-gray-400 leading-relaxed space-y-2">
                        <p class="font-bold text-yellow-500">🎮 กติกาการทดสอบ:</p>
                        <ul class="list-disc list-inside space-y-1">
                            <li>อนุญาตกล้องเว็บแคมเพื่อเริ่มจับความเคลื่อนไหว</li>
                            <li>ใช้ <span class="text-pink-400">ปลายนิ้วชี้</span> เลื่อนไปแตะที่ <span class="text-yellow-400">ดวงดาวนำโชค</span> บนจอ</li>
                            <li>หากไม่มีเว็บแคม สามารถใช้เมาส์คลิก/แตะดาวสำรองได้</li>
                            <li>ทำคะแนนให้เร็วและเยอะที่สุดแล้วกด "บันทึกคะแนนเข้าสู่ระบบ"</li>
                        </ul>
                    </div>
                </div>
            </div>

            <!-- ปุ่มบันทึกคะแนน -->
            <div class="bg-[#1f2833]/40 p-4 rounded-xl border border-purple-900/20 space-y-3">
                <button id="saveScoreBtn" onclick="saveScoreToDatabase()" 
                        class="w-full bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-500 hover:to-green-500 text-white font-bold py-3 px-4 rounded-lg transition-all duration-300 text-center uppercase tracking-wide cursor-pointer text-sm">
                    💾 บันทึกคะแนนเข้าสู่ระบบ
                </button>
                <div id="statusMessage" class="text-xs text-center font-mono py-1 rounded hidden"></div>
            </div>
        </div>

        <!-- หน้าจอแสดงผลกล้อง AR / คอนโซลเกม -->
        <div class="lg:col-span-3 flex flex-col space-y-4">
            
            <div class="relative w-full aspect-video bg-black rounded-2xl overflow-hidden border border-purple-500/30 neon-border-purple flex items-center justify-center">
                <!-- วิดีโอกล้องถูกซ่อนไว้ แต่ใช้ดึงเฟรมภาพ -->
                <video id="webcam" autoplay playsinline muted width="640" height="480" class="hidden"></video>
                
                <!-- แคนวาสหลักในการวาดวิดีโอสะท้อนกระจก แอนิเมชัน และดาว -->
                <canvas id="gameCanvas" width="640" height="480" class="w-full h-full object-cover"></canvas>

                <!-- หน้าต่าง Overlay แจ้งโหลด / เปิดกล้อง -->
                <div id="loadingOverlay" class="absolute inset-0 bg-black/90 flex flex-col items-center justify-center text-center p-6 space-y-4">
                    <div class="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-purple-500"></div>
                    <div class="text-sm font-semibold">กำลังเชื่อมต่อกล้องเว็บแคมและดาวน์โหลดสมองกลปัญญาประดิษฐ์ (MediaPipe Hands AI)...</div>
                    <p class="text-xs text-gray-500">กรุณากด 'อนุญาตการเข้าถึงกล้อง' หากบราวเซอร์ร้องขอ</p>
                    <button onclick="startMouseFallback()" class="text-xs bg-purple-950 hover:bg-purple-900 text-purple-300 px-4 py-2 rounded-lg border border-purple-800 transition-colors">
                        หรือเริ่มเล่นโหมดใช้เมาส์ทันที (Mouse Fallback)
                    </button>
                </div>

                <!-- ป้ายแสดงเมื่ออยู่ในโหมดเมาส์ -->
                <div id="mouseModeBadge" class="absolute top-4 right-4 bg-yellow-500/90 text-black text-[10px] font-bold px-2 py-1 rounded hidden uppercase tracking-wider">
                    Mouse Control Active
                </div>
            </div>

            <!-- แถบระบุสถานะกล้อง -->
            <div class="flex justify-between items-center bg-[#1f2833]/30 px-4 py-2.5 rounded-lg border border-purple-950">
                <span class="text-xs text-gray-400" id="cameraStatusText">
                    สถานะกล้อง: <span class="text-yellow-400 font-bold">กำลังรันระบบคัดกรอง...</span>
                </span>
                <span class="text-[10px] font-mono text-gray-500">ความละเอียดแนะนำ: 640 x 480 พิกเซล</span>
            </div>

        </div>

    </main>

    <!-- ลอจิกเกม AR และการสื่อสาร AJAX -->
    <script>
        const videoElement = document.getElementById('webcam');
        const canvasElement = document.getElementById('gameCanvas');
        const canvasCtx = canvasElement.getContext('2d');
        const loadingOverlay = document.getElementById('loadingOverlay');
        const currentScoreDisplay = document.getElementById('currentScoreDisplay');
        const statusMessage = document.getElementById('statusMessage');
        const cameraStatusText = document.getElementById('cameraStatusText');
        const mouseModeBadge = document.getElementById('mouseModeBadge');

        // สถานะของเกม
        let score = 0;
        let isCameraActive = false;
        let isMouseMode = false;
        let star = { x: 320, y: 240, radius: 25, color: '#facc15' }; // ดาวนำโชค
        let handCursor = { x: -100, y: -100, isTracking: false }; // พิกัดนิ้วชี้ของผู้เล่น

        // สุ่มพิกัดดาวใหม่
        function spawnStar() {
            // หลีกเลี่ยงขอบจอเพื่อให้นิ้วแตะโดนง่ายขึ้น
            star.x = Math.floor(Math.random() * (canvasElement.width - 100)) + 50;
            star.y = Math.floor(Math.random() * (canvasElement.height - 100)) + 50;
        }

        // เช็กการชนกัน (Collision Detection)
        function checkCollision(x1, y1, x2, y2, r1, r2) {
            const distance = Math.hypot(x2 - x1, y2 - y1);
            return distance < (r1 + r2);
        }

        // เพิ่มคะแนน
        function incrementScore() {
            score++;
            currentScoreDisplay.textContent = score;
            spawnStar();
            // เสียงเอฟเฟกต์ยิงความถึ่สังเคราะห์แบบเรียลไทม์ (Audio Synthesizer) เพื่อความไฮเทค
            playBeepSound();
        }

        // สร้างเอฟเฟกต์เสียงด้วย Web Audio API โดยไม่ต้องพึ่งพาไฟล์เสียงภายนอก
        function playBeepSound() {
            try {
                const audioCtx = new (window.AudioContext || window.webkitAudioContext)();
                const oscillator = audioCtx.createOscillator();
                const gainNode = audioCtx.createGain();
                
                oscillator.type = 'sine';
                oscillator.frequency.setValueAtTime(880, audioCtx.currentTime); // โน้ตความถี่สูงสะใจ
                gainNode.gain.setValueAtTime(0.1, audioCtx.currentTime);
                gainNode.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.1);
                
                oscillator.connect(gainNode);
                gainNode.connect(audioCtx.destination);
                oscillator.start();
                oscillator.stop(audioCtx.currentTime + 0.12);
            } catch (e) {
                // เบราว์เซอร์ไม่รองรับบล็อกเสียงชั่วคราว
            }
        }

        // เมื่อเริ่มโหมดใช้เมาส์เป็นสำรอง
        function startMouseFallback() {
            isMouseMode = true;
            loadingOverlay.style.display = 'none';
            mouseModeBadge.classList.remove('hidden');
            cameraStatusText.innerHTML = 'สถานะกล้อง: <span class="text-orange-400 font-bold">ใช้เมาส์ขยับเพื่อทดสอบแทนกล้อง</span>';
            spawnStar();
            requestAnimationFrame(gameLoop);
        }

        // ตรวจพิกัดเมาส์สำหรับโหมดเมาส์สำรอง
        canvasElement.addEventListener('mousemove', function(e) {
            if (!isMouseMode) return;
            const rect = canvasElement.getBoundingClientRect();
            // แปลงพิกัดการสัมผัสตามขนาดแคนวาสจริง
            handCursor.x = (e.clientX - rect.left) * (canvasElement.width / rect.width);
            handCursor.y = (e.clientY - rect.top) * (canvasElement.height / rect.height);
            handCursor.isTracking = true;
        });

        canvasElement.addEventListener('mouseleave', function() {
            if (isMouseMode) {
                handCursor.isTracking = false;
            }
        });

        // ลูปรันหน้าต่างเกม (สำหรับโหมดสำรอง และแอนิเมชันวิดีโอ)
        function gameLoop() {
            canvasCtx.clearRect(0, 0, canvasElement.width, canvasElement.height);

            if (isMouseMode) {
                // พื้นหลังสีมืดสไตล์นีออนในโหมดเมาส์
                canvasCtx.fillStyle = '#0f172a';
                canvasCtx.fillRect(0, 0, canvasElement.width, canvasElement.height);
                
                // ตกแต่งพื้นหลังสไตล์ตาราง Grid
                canvasCtx.strokeStyle = 'rgba(168, 85, 247, 0.1)';
                canvasCtx.lineWidth = 1;
                for (let i = 0; i < canvasElement.width; i += 40) {
                    canvasCtx.beginPath();
                    canvasCtx.moveTo(i, 0);
                    canvasCtx.lineTo(i, canvasElement.height);
                    canvasCtx.stroke();
                }
                for (let j = 0; j < canvasElement.height; j += 40) {
                    canvasCtx.beginPath();
                    canvasCtx.moveTo(0, j);
                    canvasCtx.lineTo(canvasElement.width, j);
                    canvasCtx.stroke();
                }
            }

            // วาดเป้าดาวนำโชค
            drawStar(canvasCtx, star.x, star.y, 5, star.radius, star.radius / 2.2, star.color);

            // วาดจุดสัมผัสของผู้เล่น
            if (handCursor.isTracking) {
                // เอฟเฟกต์จุดสีชมพูนีออนส่องสว่าง
                canvasCtx.beginPath();
                canvasCtx.arc(handCursor.x, handCursor.y, 12, 0, 2 * Math.PI);
                canvasCtx.fillStyle = 'rgba(236, 72, 153, 0.8)';
                canvasCtx.shadowBlur = 15;
                canvasCtx.shadowColor = '#ec4899';
                canvasCtx.fill();
                canvasCtx.shadowBlur = 0; // รีเซ็ต

                // วาดเป้าครอบปลายนิ้ว
                canvasCtx.beginPath();
                canvasCtx.arc(handCursor.x, handCursor.y, 22, 0, 2 * Math.PI);
                canvasCtx.strokeStyle = '#ec4899';
                canvasCtx.lineWidth = 2;
                canvasCtx.stroke();

                // ตรวจสอบความถูกต้องของการชน
                if (checkCollision(handCursor.x, handCursor.y, star.x, star.y, 12, star.radius)) {
                    incrementScore();
                }
            }

            requestAnimationFrame(gameLoop);
        }

        // ฟังก์ชันวาดรูปดวงดาวนำโชค 5 แฉก
        function drawStar(ctx, cx, cy, spikes, outerRadius, innerRadius, color) {
            let rot = Math.PI / 2 * 3;
            let x = cx;
            let y = cy;
            let step = Math.PI / spikes;

            ctx.beginPath();
            ctx.moveTo(cx, cy - outerRadius);
            for (let i = 0; i < spikes; i++) {
                x = cx + Math.cos(rot) * outerRadius;
                y = cy + Math.sin(rot) * outerRadius;
                ctx.lineTo(x, y);
                rot += step;

                x = cx + Math.cos(rot) * innerRadius;
                y = cy + Math.sin(rot) * innerRadius;
                ctx.lineTo(x, y);
                rot += step;
            }
            ctx.lineTo(cx, cy - outerRadius);
            ctx.closePath();
            
            ctx.shadowBlur = 20;
            ctx.shadowColor = color;
            ctx.fillStyle = color;
            ctx.fill();
            ctx.shadowBlur = 0; // รีเซ็ต

            // วาดเส้นขอบทองหรูหรา
            ctx.strokeStyle = '#ffffff';
            ctx.lineWidth = 1.5;
            ctx.stroke();
        }

        // ลอจิกการทำงานกล้องและ AI ตรวจจับพิกัดมือ
        function onResults(results) {
            // ลบแคนวาสเดิม
            canvasCtx.save();
            canvasCtx.clearRect(0, 0, canvasElement.width, canvasElement.height);

            // วาดภาพจากกล้องเว็บแคม (และทำ mirror สะท้อนกลับซ้ายขวาเพื่อการเล่นที่เป็นธรรมชาติ)
            canvasCtx.translate(canvasElement.width, 0);
            canvasCtx.scale(-1, 1);
            canvasCtx.drawImage(results.image, 0, 0, canvasElement.width, canvasElement.height);
            canvasCtx.restore(); // นำการหมุนกระจกกลับคืนสู่ค่าปกติ

            handCursor.isTracking = false;

            // ตรวจสอบว่ากล้องตรวจเจอมือหรือไม่
            if (results.multiHandLandmarks && results.multiHandLandmarks.length > 0) {
                const landmarks = results.multiHandLandmarks[0];
                
                // หยิบพิกัดข้อต่อที่ 8 (Index Finger Tip - ปลายนิ้วชี้)
                const indexFinger = landmarks[8];
                
                // นำพิกัดปลายนิ้วแบบ Ratio (0.0 ถึง 1.0) มาคำนวณเข้าพิกัดแคนวาสจริง
                // ทำการคำนวณ mirror จากขวามาซ้าย เนื่องจากเรากระจกกล้องวิดีโอ
                handCursor.x = (1 - indexFinger.x) * canvasElement.width;
                handCursor.y = indexFinger.y * canvasElement.height;
                handCursor.isTracking = true;
            }

            // วาดดาวดาวนำโชค
            drawStar(canvasCtx, star.x, star.y, 5, star.radius, star.radius / 2.2, star.color);

            // วาดพิกัดสัมผัสเมื่อเจอมือ
            if (handCursor.isTracking) {
                canvasCtx.beginPath();
                canvasCtx.arc(handCursor.x, handCursor.y, 14, 0, 2 * Math.PI);
                canvasCtx.fillStyle = 'rgba(168, 85, 247, 0.9)'; // สีม่วงนีออน
                canvasCtx.shadowBlur = 15;
                canvasCtx.shadowColor = '#a855f7';
                canvasCtx.fill();
                canvasCtx.shadowBlur = 0;

                canvasCtx.beginPath();
                canvasCtx.arc(handCursor.x, handCursor.y, 25, 0, 2 * Math.PI);
                canvasCtx.strokeStyle = '#22c55e'; // สีเขียวนีออนยืนยันการแทรคกิ้ง
                canvasCtx.lineWidth = 2.5;
                canvasCtx.stroke();

                // ตรวจสอบการชนกันระหว่าง ปลายนิ้วผู้เล่น กับ ดาวนำโชค
                if (checkCollision(handCursor.x, handCursor.y, star.x, star.y, 14, star.radius)) {
                    incrementScore();
                }
            }
        }

        // ทำการตั้งค่ากล้องเว็บแคมผ่านโครงสร้าง MediaPipe
        const hands = new Hands({
            locateFile: (file) => \`https://cdn.jsdelivr.net/npm/@mediapipe/hands/\${file}\`
        });

        hands.setOptions({
            maxNumHands: 1, // ติดตามเพียงมือเดียวเท่านั้นเพื่อประหยัดทรัพยากร
            modelComplexity: 1,
            minDetectionConfidence: 0.6,
            minTrackingConfidence: 0.6
        });

        hands.onResults(onResults);

        // ดักจับข้อยกเว้นกรณีเครื่องไม่มีเว็บแคมหรือปฏิเสธสิทธิ์
        const cameraObj = new Camera(videoElement, {
            onFrame: async () => {
                if (!isMouseMode) {
                    await hands.send({ image: videoElement });
                }
            },
            width: 640,
            height: 480
        });

        cameraObj.start()
            .then(() => {
                isCameraActive = true;
                loadingOverlay.style.display = 'none';
                cameraStatusText.innerHTML = 'สถานะกล้อง: <span class="text-green-400 font-bold">🟢 ทำงานสมบูรณ์ (โหมดวิเคราะห์ขยับมือเปิดใช้งาน)</span>';
                spawnStar();
            })
            .catch((err) => {
                console.warn("ไม่สามารถเรียกกล้องหน้าได้ กำลังเปลี่ยนเข้าสู่โหมดเมาส์: ", err);
                cameraStatusText.innerHTML = 'สถานะกล้อง: <span class="text-red-400 font-bold">🔴 เข้าถึงกล้องไม่ได้ เปลี่ยนเป็นโหมดเมาส์สำรองแล้ว</span>';
                startMouseFallback();
            });


        // ฟังก์ชันส่งบันทึกคะแนนไปยังฝั่งเซิร์ฟเวอร์ด้วย Fetch API (AJAX)
        function saveScoreToDatabase() {
            const saveBtn = document.getElementById('saveScoreBtn');
            saveBtn.disabled = true;
            saveBtn.innerHTML = 'กำลังทำรายการ...';

            statusMessage.classList.remove('hidden', 'bg-red-950/40', 'border-red-500', 'text-red-300', 'bg-emerald-950/40', 'border-emerald-500', 'text-emerald-300');

            fetch('game.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ score: score })
            })
            .then(response => {
                if (!response.ok) {
                    throw new Error('ไม่สามารถบันทึกข้อมูลกับเซิร์ฟเวอร์ได้');
                }
                return response.json();
            })
            .then(data => {
                statusMessage.classList.remove('hidden');
                
                if (data.success) {
                    // อัปเดตแสดงคะแนนสูงสุดของสิทธิ์ผู้ใช้ในปัจจุบันบนจอ
                    document.getElementById('personalHighScore').textContent = data.high_score + ' คะแนน';
                    
                    statusMessage.className = "text-xs text-center font-mono py-2 rounded border bg-emerald-950/40 border-emerald-500 text-emerald-300";
                    if (data.isNewHighScore) {
                        statusMessage.innerHTML = '🏆 <strong>' + data.message + '</strong> (สถิติปัจจุบัน: ' + data.high_score + ' คะแนน)';
                    } else {
                        statusMessage.innerHTML = 'ℹ️ ' + data.message + ' (คะแนนสถิติเดิมของคุณยังดีกว่าที่เล่นรอบนี้)';
                    }
                } else {
                    statusMessage.className = "text-xs text-center font-mono py-2 rounded border bg-red-950/40 border-red-500 text-red-300";
                    statusMessage.textContent = '❌ ล้มเหลว: ' + data.message;
                }
            })
            .catch(error => {
                statusMessage.classList.remove('hidden');
                statusMessage.className = "text-xs text-center font-mono py-2 rounded border bg-red-950/40 border-red-500 text-red-300";
                statusMessage.textContent = '❌ เกิดข้อผิดพลาดเครือข่าย: ' + error.message;
            })
            .finally(() => {
                saveBtn.disabled = false;
                saveBtn.innerHTML = '💾 บันทึกคะแนนเข้าสู่ระบบ';
            });
        }
    </script>

    <!-- Footer -->
    <footer class="border-t border-purple-900/20 bg-black/40 py-6 text-center text-xs text-gray-500">
        <div class="max-w-7xl mx-auto px-4">
            <p>&copy; 2026 NEXUS ESPORTS CLUB. All Rights Reserved. Selection Server v1.0.4</p>
        </div>
    </footer>

</body>
</html>`
    },
    "logout.php": {
      desc: "ไฟล์สคริปต์ออกจากระบบล้างเซสชัน (logout.php)",
      lang: "php",
      code: `<?php
// logout.php
// ไฟล์สคริปต์สำหรับออกจากระบบและทำลาย Session ทั้งหมด

session_start();
session_unset();
session_destroy();

header("Location: index.php");
exit();
?>`
    }
  };

  const handleCopy = (filename: string, codeText: string) => {
    navigator.clipboard.writeText(codeText);
    setCopiedFile(filename);
    setTimeout(() => setCopiedFile(null), 2500);
  };

  const handleDownloadZip = () => {
    alert("💡 คุณสามารถทำการคัดลอกโค้ดแต่ละไฟล์ในแท็บด้านล่างไปเซฟเพื่อรันบน AppServ ในเครื่องได้ทันทีครับ!");
  };

  return (
    <div className="space-y-8">
      {/* ส่วนหัวแนะนำการนำไปประกอบร่างรันจริงบน AppServ */}
      <div className="bg-zinc-900/50 p-8 border border-white/10 backdrop-blur-sm relative">
        <div className="absolute top-0 right-0 bg-white/10 text-white px-2 py-0.5 text-[8px] font-mono uppercase tracking-wider">
          GUIDE_NODE
        </div>
        <div className="flex items-center space-x-3 mb-6">
          <div className="p-2.5 bg-white/5 border border-white/10 text-[#00ff9d]">
            <BookOpen size={20} />
          </div>
          <div>
            <h2 className="text-base font-bold tracking-tight text-white uppercase font-display">คู่มือการติดตั้งบนเซิร์ฟเวอร์จำลอง AppServ (MySQL / phpMyAdmin)</h2>
            <p className="text-xs text-zinc-500 mt-1">วิธีการติดตั้งซอร์สโค้ด PHP/MySQL เหล่านี้ไปรันเป็นระบบเว็บจริงในเครื่องคอมพิวเตอร์ของคุณ</p>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs text-zinc-300 leading-relaxed mt-4 pt-6 border-t border-white/10">
          {/* ฝั่งฐานข้อมูล */}
          <div className="space-y-3 bg-black/40 p-5 border border-white/5">
            <h4 className="font-bold text-[#00ff9d] flex items-center space-x-1.5 uppercase tracking-wider font-mono">
              <Database size={13} />
              <span>ขั้นตอนเตรียมฐานข้อมูล (phpMyAdmin):</span>
            </h4>
            <ol className="list-decimal list-inside space-y-2 text-zinc-400 text-[11px]">
              <li>เปิดเบราว์เซอร์แล้วเข้าสู่ระบบ <code className="text-[#00ff9d] font-mono">http://localhost/phpmyadmin</code></li>
              <li>สร้างฐานข้อมูลใหม่ชื่อว่า <code className="text-white font-bold font-mono">esports_db</code> เลือก Collation เป็น <code className="font-mono">utf8mb4_unicode_ci</code></li>
              <li>คลิกไปที่ฐานข้อมูล <code className="text-white font-mono">esports_db</code> แล้วเลือกแท็บเมนู <code className="text-white font-semibold">SQL</code> ด้านบน</li>
              <li>คัดลอกโค้ดทั้งหมดจากแท็บ <span className="text-[#00ff9d] font-semibold font-mono">"schema.sql"</span> ด้านล่างนี้ ไปวางในช่องกรอกแล้วกด <span className="text-[#00ff9d] font-semibold">Go / รัน</span></li>
            </ol>
          </div>

          {/* ฝั่งโฟลเดอร์รันโค้ด */}
          <div className="space-y-3 bg-black/40 p-5 border border-white/5">
            <h4 className="font-bold text-[#00ff9d] flex items-center space-x-1.5 uppercase tracking-wider font-mono">
              <Terminal size={13} />
              <span>ขั้นตอนรันไฟล์โค้ด (AppServ Root):</span>
            </h4>
            <ol className="list-decimal list-inside space-y-2 text-zinc-400 text-[11px]">
              <li>เข้าไปที่โฟลเดอร์รากของเซิร์ฟเวอร์คุณ (สำหรับ AppServ คือ <code className="text-[#00ff9d] font-mono">C:\AppServ\www\</code>)</li>
              <li>สร้างโฟลเดอร์ใหม่ภายใน www ชื่อว่า <code className="text-white font-bold font-mono">esports</code></li>
              <li>สร้างและคัดลอกโค้ดแต่ละไฟล์ด้านล่างเซฟลงในโฟลเดอร์ <code className="text-[#00ff9d] font-mono">C:\AppServ\www\esports\</code> :<br />
                <span className="text-white font-mono font-bold block mt-1">db.config.php, index.php, register.php, game.php, logout.php</span>
              </li>
              <li>เปิดเบราว์เซอร์ไปที่ <code className="text-[#00ff9d] font-bold font-mono">http://localhost/esports/index.php</code> เพื่อรันจริง!</li>
            </ol>
          </div>
        </div>

        {/* กล่องคำเตือนเรื่องกล้อง */}
        <div className="mt-6 p-4 bg-yellow-500/5 border border-yellow-500/20 text-yellow-500 text-[11px] leading-relaxed">
          <div className="flex items-center space-x-1.5 font-bold mb-1 uppercase tracking-wider">
            <AlertCircle size={13} />
            <span>คำแนะนำเรื่องกล้อง Webcam ในเว็บจริง:</span>
          </div>
          <p>
            การรันกล้องและ MediaPipe AI บนเว็บเบราว์เซอร์สมัยใหม่ ต้องการการเชื่อมต่อแบบปลอดภัยสูงสุด 
            ซึ่งการเปิดบนเครื่อง Localhost (http://localhost) จะอนุญาตให้เรียกกล้องได้ตามปกติครับ แต่หากต้องการอัปโหลดขึ้นเว็บจริงภายนอก จะต้องติดตั้งใบรับรองความปลอดภัย <code className="text-white font-mono bg-yellow-500/10 px-1">HTTPS</code> เท่านั้นจึงจะใช้กล้องได้ครับ
          </p>
        </div>
      </div>

      {/* แท็บซอร์สโค้ด PHP แต่ละไฟล์ */}
      <div className="bg-zinc-900/50 border border-white/10 shadow-xl overflow-hidden backdrop-blur-sm">
        
        {/* หัวข้อแท็บชื่อไฟล์ */}
        <div className="bg-black/60 border-b border-white/10 px-4 py-3 flex flex-wrap gap-2">
          {Object.keys(phpFiles).map((filename) => (
            <button
              key={filename}
              onClick={() => setActiveFile(filename)}
              className={`px-4 py-2 text-xs font-mono font-bold uppercase tracking-wider transition-all duration-200 cursor-pointer ${
                activeFile === filename
                  ? "bg-white text-black font-black"
                  : "text-zinc-500 hover:text-white"
              }`}
            >
              {filename}
            </button>
          ))}
        </div>

        {/* เนื้อหาไฟล์ */}
        <div className="p-6 space-y-4">
          <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
            <div>
              <span className="bg-zinc-950 text-[#00ff9d] border border-white/10 px-3 py-1 font-mono font-bold text-[9px] uppercase tracking-wider">
                {activeFile.endsWith(".sql") ? "DATABASE SCHEMA SQL" : "PHP CODE FILE"}
              </span>
              <p className="text-xs text-zinc-400 mt-2">{phpFiles[activeFile].desc}</p>
            </div>

            {/* ปุ่มก๊อปปี้ */}
            <button
              onClick={() => handleCopy(activeFile, phpFiles[activeFile].code)}
              className="flex items-center space-x-2 bg-zinc-950 hover:bg-zinc-900 border border-white/10 hover:border-white/20 text-zinc-300 hover:text-white text-xs font-bold px-4 py-2.5 transition-all duration-150 cursor-pointer uppercase tracking-widest font-mono"
            >
              {copiedFile === activeFile ? (
                <>
                  <Check size={14} className="text-[#00ff9d]" />
                  <span className="text-[#00ff9d]">COPIED</span>
                </>
              ) : (
                <>
                  <Copy size={14} />
                  <span>COPY CODE</span>
                </>
              )}
            </button>
          </div>

          {/* ช่องแสดงโค้ด */}
          <div className="relative">
            <textarea
              readOnly
              value={phpFiles[activeFile].code}
              className="w-full h-[380px] bg-[#050505] text-zinc-300 font-mono text-[11.5px] p-4 border border-white/10 focus:outline-none resize-none leading-relaxed overflow-y-auto"
              style={{ whiteSpace: "pre", wordWrap: "normal" }}
            />
          </div>
        </div>

      </div>
    </div>
  );
}
