import React, { useState, useEffect } from "react";
import { LogIn, ArrowRight, ShieldCheck, Cpu, Flame, Trophy } from "lucide-react";
import { User } from "../types";

interface LoginViewProps {
  onLoginSuccess: (user: User, token: string) => void;
  onNavigateToRegister: () => void;
}

interface LeaderboardItem {
  username: string;
  name: string;
  high_score: number;
}

export default function LoginView({ onLoginSuccess, onNavigateToRegister }: LoginViewProps) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [leaderboard, setLeaderboard] = useState<LeaderboardItem[]>([]);

  // Fetch Leaderboard for real gaming atmosphere
  useEffect(() => {
    fetch("/api/leaderboard")
      .then((res) => res.json())
      .then((data) => {
        if (Array.isArray(data)) {
          setLeaderboard(data);
        }
      })
      .catch((err) => console.error("Error fetching leaderboard:", err));
  }, []);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);

    try {
      const res = await fetch("/api/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ username, password }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || "เข้าสู่ระบบล้มเหลว");
      }

      onLoginSuccess(data.user, data.token);
    } catch (err: any) {
      setError(err.message || "เกิดข้อผิดพลาดในการเชื่อมต่อเซิร์ฟเวอร์");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
      {/* ข้อมูลแนะนำโครงการ / มโนเนื้อหา */}
      <div className="lg:col-span-7 space-y-8">
        <div className="inline-flex items-center space-x-2 bg-[#00ff9d]/5 text-[#00ff9d] border border-[#00ff9d]/20 px-4 py-1.5 text-xs font-bold tracking-[0.2em] uppercase">
          <Flame size={12} className="animate-pulse" />
          <span>Now Recruiting 2026</span>
        </div>
        
        <div>
          <h2 className="text-[#00ff9d] text-xs font-bold tracking-[0.3em] mb-4 uppercase font-display">Pro Scouting Portal</h2>
          <h1 className="text-5xl md:text-6xl lg:text-7xl font-black leading-[0.9] tracking-tighter uppercase italic text-white font-display">
            Become<br />The Next<br />
            <span className="text-transparent text-stroke-white opacity-60">LEGEND</span>
          </h1>
        </div>
        
        <p className="text-zinc-400 leading-relaxed text-sm md:text-base max-w-xl">
          โอกาสทองครั้งสำคัญในการก้าวเข้าสู่ทีม <span className="text-[#00ff9d] font-bold">NEXUS ESPORTS</span> สังกัดชั้นนำระดับโลก 
          เรากำลังเฟ้นหานักกีฬาหน้าใหม่ที่มีความสามารถเชิงปฏิกิริยาการตอบสนองที่ฉับไว แม่นยำ และมีความตั้งใจจริง
        </p>
        
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-4">
          <div className="p-5 bg-zinc-900/50 border border-white/10 backdrop-blur-sm">
            <div className="text-2xl font-black text-[#00ff9d] font-display">$100,000+</div>
            <div className="text-[10px] text-zinc-500 uppercase tracking-widest mt-1">เงินรางวัล & สัญญาอาชีพ</div>
          </div>
          <div className="p-5 bg-zinc-900/50 border border-white/10 backdrop-blur-sm">
            <div className="text-2xl font-black text-white font-display">AR TRAINING</div>
            <div className="text-[10px] text-zinc-500 uppercase tracking-widest mt-1">ทดสอบผ่านกล้องสัมผัส</div>
          </div>
          <div className="p-5 bg-zinc-900/50 border border-[#00ff9d]/20 backdrop-blur-sm">
            <div className="text-2xl font-black text-[#00ff9d] font-display">GLOBAL TEAM</div>
            <div className="text-[10px] text-zinc-500 uppercase tracking-widest mt-1">สนับสนุนในระดับสากล</div>
          </div>
        </div>

        {/* ตารางจัดอันดับจำลอง เพื่อสร้าง Vibe อีสปอร์ตอย่างแท้จริง */}
        <div className="p-6 bg-zinc-900/30 border border-white/10 backdrop-blur-sm">
          <div className="flex justify-between items-end mb-6">
            <h3 className="text-xs font-bold tracking-[0.2em] uppercase text-zinc-300 flex items-center space-x-2 font-display">
              <Trophy size={14} className="text-yellow-500" />
              <span>อันดับคะแนนทดสอบปฏิกิริยา (Leaderboard)</span>
            </h3>
            <div className="text-[#00ff9d] text-[10px] font-mono tracking-widest">LIVE_TERMINAL_FEED</div>
          </div>
          
          {leaderboard.length === 0 ? (
            <p className="text-xs text-zinc-500 italic">ยังไม่มีข้อมูลสถิติผู้สมัคร (รอคุณมาเป็นคนแรก!)</p>
          ) : (
            <div className="space-y-2">
              {leaderboard.map((player, index) => (
                <div key={index} className="flex justify-between items-center bg-black/40 px-4 py-2.5 border border-white/5 text-xs">
                  <div className="flex items-center space-x-3">
                    <span className={`w-5 h-5 flex items-center justify-center font-bold font-mono text-[10px] ${
                      index === 0 ? "bg-[#00ff9d] text-black" : index === 1 ? "bg-white text-black" : index === 2 ? "bg-zinc-700 text-white" : "bg-zinc-900 text-zinc-500"
                    }`}>
                      {index + 1}
                    </span>
                    <span className="text-white font-bold">{player.name}</span>
                    <span className="text-zinc-500 font-mono">({player.username})</span>
                  </div>
                  <span className="text-[#00ff9d] font-extrabold font-mono">{player.high_score} PTS</span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* ฟอร์มล็อกอิน */}
      <div className="lg:col-span-5">
        <div className="w-full max-w-md mx-auto bg-zinc-900/50 p-8 border border-white/10 backdrop-blur-sm relative">
          <div className="absolute top-0 right-0 bg-[#00ff9d] text-black px-2 py-0.5 text-[9px] font-mono font-bold uppercase tracking-wider">
            SECURE_NODE
          </div>
          <div className="mb-8">
            <h3 className="text-[10px] font-bold tracking-[0.3em] uppercase text-[#00ff9d] mb-2 font-display">Authentication</h3>
            <h2 className="text-2xl font-black text-white uppercase italic tracking-tight font-display">Access Terminal</h2>
            <p className="text-xs text-zinc-500 mt-1">เข้าสู่เซิร์ฟเวอร์คัดเลือกเพื่อเริ่มการทดสอบ</p>
          </div>

          {error && (
            <div className="mb-6 p-4 bg-red-950/20 border border-red-800/50 text-red-300 text-xs text-center font-mono font-semibold">
              ⚠️ {error}
            </div>
          )}

          <form onSubmit={handleLogin} className="space-y-6">
            <div>
              <label htmlFor="username" className="block text-[10px] uppercase tracking-widest text-zinc-500 mb-2 font-mono">
                Codename / Username (ชื่อผู้ใช้)
              </label>
              <input
                type="text"
                id="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="ENTER USERNAME"
                required
                className="w-full bg-transparent border-b border-white/20 py-2.5 text-sm focus:outline-none focus:border-[#00ff9d] placeholder:text-zinc-700 text-white transition-colors font-mono"
              />
            </div>

            <div>
              <label htmlFor="password" className="block text-[10px] uppercase tracking-widest text-zinc-500 mb-2 font-mono">
                Secure Key / Password (รหัสผ่าน)
              </label>
              <input
                type="password"
                id="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
                required
                className="w-full bg-transparent border-b border-white/20 py-2.5 text-sm focus:outline-none focus:border-[#00ff9d] placeholder:text-zinc-700 text-white transition-colors"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full py-4 bg-[#00ff9d] text-black font-black text-xs uppercase tracking-widest hover:bg-white transition-colors cursor-pointer disabled:opacity-55 font-mono"
            >
              {loading ? "AUTHENTICATING..." : "ACCESS TERMINAL"}
            </button>
          </form>

          <div className="mt-8 pt-6 border-t border-white/10 text-center space-y-4">
            <p className="text-xs text-zinc-500">ยังไม่มีบัญชีผู้ใช้สมัครในสโมสร?</p>
            <button
              onClick={onNavigateToRegister}
              className="w-full py-3 border border-white/10 hover:border-white/30 text-zinc-300 hover:text-white text-xs uppercase tracking-widest transition-all cursor-pointer font-bold"
            >
              Need Credentials? Register Here
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
