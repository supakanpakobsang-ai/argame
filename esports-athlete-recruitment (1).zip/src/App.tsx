import React, { useState, useEffect } from "react";
import { User } from "./types";
import Navbar from "./components/Navbar";
import LoginView from "./components/LoginView";
import RegisterView from "./components/RegisterView";
import GameView from "./components/GameView";
import CodeViewer from "./components/CodeViewer";

export default function App() {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState<string>("home");
  const [checkingSession, setCheckingSession] = useState(true);

  // ตรวจสอบสถานะเซสชันการเข้าสู่ระบบตั้งแต่เปิดแอป
  useEffect(() => {
    const token = localStorage.getItem("nexus_token");
    if (token) {
      fetch("/api/me", {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
        .then((res) => {
          if (!res.ok) {
            throw new Error("Session หมดอายุ");
          }
          return res.json();
        })
        .then((user) => {
          setCurrentUser(user);
          setActiveTab("game"); // ถ้าล็อกอินแล้ว นำเข้าสู่หน้าเกมทดสอบโดยตรง
        })
        .catch((err) => {
          console.warn(err.message);
          localStorage.removeItem("nexus_token");
        })
        .finally(() => {
          setCheckingSession(false);
        });
    } else {
      setCheckingSession(false);
    }
  }, []);

  const handleLoginSuccess = (user: User, token: string) => {
    localStorage.setItem("nexus_token", token);
    setCurrentUser(user);
    setActiveTab("game"); // นำส่งเข้าสู่หน้าเกมทันทีเมื่อล็อกอินเสร็จสมบูรณ์
  };

  const handleLogout = () => {
    localStorage.removeItem("nexus_token");
    setCurrentUser(null);
    setActiveTab("home");
  };

  const handleScoreSaved = (newHighScore: number) => {
    if (currentUser) {
      setCurrentUser({
        ...currentUser,
        high_score: newHighScore,
      });
    }
  };

  return (
    <div className="bg-[#050505] text-white font-sans min-h-screen flex flex-col justify-between selection:bg-[#00ff9d] selection:text-black border-4 border-[#1a1a1a]">
      {/* ส่วนหัวเมนูนำทางหลัก */}
      <Navbar
        currentUser={currentUser}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onLogout={handleLogout}
      />

      {/* พื้นที่คอนเทนต์หลักสลับตามแท็บ */}
      <main className="max-w-7xl mx-auto px-6 py-12 flex-grow w-full flex items-center justify-center relative">
        <div className="absolute top-0 right-0 w-[300px] h-[300px] bg-[#00ff9d]/5 rounded-full blur-[100px] -z-10 pointer-events-none"></div>
        {checkingSession ? (
          <div className="flex flex-col items-center justify-center text-center space-y-4">
            <div className="animate-spin rounded-full h-10 w-10 border-t-2 border-b-2 border-[#00ff9d] editorial-glow-strong"></div>
            <p className="text-xs text-[#00ff9d] font-mono tracking-widest uppercase">กำลังเชื่อมข้อมูลผู้ใช้กับเซิร์ฟเวอร์...</p>
          </div>
        ) : (
          <div className="w-full">
            {activeTab === "home" && (
              <LoginView
                onLoginSuccess={handleLoginSuccess}
                onNavigateToRegister={() => setActiveTab("register")}
              />
            )}

            {activeTab === "register" && (
              <RegisterView
                onRegisterSuccess={() => setActiveTab("home")}
                onNavigateToLogin={() => setActiveTab("home")}
              />
            )}

            {activeTab === "game" && (
              <GameView
                currentUser={currentUser}
                onScoreSaved={handleScoreSaved}
              />
            )}

            {activeTab === "code" && <CodeViewer />}
          </div>
        )}
      </main>

      {/* ส่วนท้ายแสดงลิขสิทธิ์สากล */}
      <footer className="border-t border-white/10 bg-black/80 py-6 text-center text-xs text-zinc-500">
        <div className="max-w-7xl mx-auto px-6 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="tracking-wider text-[11px] uppercase">&copy; 2026 NEXUS ESPORTS CLUB. All Rights Reserved.</p>
          <div className="flex items-center space-x-2 text-[10px] text-zinc-600 font-mono">
            <span>PREVIEW SERVER V1.0.4 (NODE.JS + REACT + EXPRESS)</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
