/**
 * Types and interfaces for the Esports Recruitment App
 */

export interface User {
  id: string;
  username: string;
  name: string;
  email: string;
  phone: string;
  high_score: number;
}

export interface PHPFile {
  name: string;
  language: string;
  code: string;
  description: string;
}
