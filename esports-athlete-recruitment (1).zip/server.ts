import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";

const app = express();
const PORT = 3000;
const DB_FILE = path.join(process.cwd(), "users_db.json");

app.use(express.json());

// User Interface
interface User {
  id: string;
  username: string;
  passwordHash: string; // We'll store standard string or simple hashed string
  name: string;
  email: string;
  phone: string;
  high_score: number;
}

// Initialize and read the database
function readDb(): User[] {
  if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(DB_FILE, JSON.stringify([]));
  }
  try {
    const data = fs.readFileSync(DB_FILE, "utf-8");
    return JSON.parse(data || "[]");
  } catch (err) {
    console.error("Error reading database:", err);
    return [];
  }
}

// Write to database
function writeDb(users: User[]) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(users, null, 2));
  } catch (err) {
    console.error("Error writing database:", err);
  }
}

// Simple in-memory sessions for the preview environment
const sessions = new Map<string, string>(); // token -> userId

// API Routes
app.get("/api/health", (req, res) => {
  res.json({ status: "ok" });
});

// Register
app.post("/api/register", (req, res) => {
  const { username, password, name, email, phone } = req.body;

  if (!username || !password || !name || !email || !phone) {
    return res.status(400).json({ error: "กรุณากรอกข้อมูลให้ครบถ้วน" });
  }

  const users = readDb();

  // Check if username already exists
  if (users.some((u) => u.username.toLowerCase() === username.toLowerCase())) {
    return res.status(400).json({ error: "Username นี้ถูกใช้งานแล้ว" });
  }

  // Check if email already exists
  if (users.some((u) => u.email.toLowerCase() === email.toLowerCase())) {
    return res.status(400).json({ error: "อีเมลนี้ถูกใช้งานแล้ว" });
  }

  const newUser: User = {
    id: "_" + Math.random().toString(36).substr(2, 9),
    username,
    passwordHash: password, // In simple preview, we store password as-is or plain for simplicity
    name,
    email,
    phone,
    high_score: 0,
  };

  users.push(newUser);
  writeDb(users);

  res.status(201).json({
    message: "สมัครสมาชิกสำเร็จ!",
    username: newUser.username,
  });
});

// Login
app.post("/api/login", (req, res) => {
  const { username, password } = req.body;

  if (!username || !password) {
    return res.status(400).json({ error: "กรุณากรอก Username และ Password" });
  }

  const users = readDb();
  const user = users.find(
    (u) => u.username.toLowerCase() === username.toLowerCase() && u.passwordHash === password
  );

  if (!user) {
    return res.status(401).json({ error: "Username หรือ Password ไม่ถูกต้อง" });
  }

  // Generate simple token
  const token = "token_" + Math.random().toString(36).substr(2, 18);
  sessions.set(token, user.id);

  res.json({
    message: "เข้าสู่ระบบสำเร็จ",
    token,
    user: {
      id: user.id,
      username: user.username,
      name: user.name,
      email: user.email,
      phone: user.phone,
      high_score: user.high_score,
    },
  });
});

// Get Current User (Session-based)
app.get("/api/me", (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) {
    return res.status(401).json({ error: "ไม่ได้ล็อกอิน" });
  }

  const token = authHeader.replace("Bearer ", "");
  const userId = sessions.get(token);

  if (!userId) {
    return res.status(401).json({ error: "Session หมดอายุหรือไม่มีประสิทธิภาพ" });
  }

  const users = readDb();
  const user = users.find((u) => u.id === userId);

  if (!user) {
    return res.status(404).json({ error: "ไม่พบข้อมูลผู้ใช้" });
  }

  res.json({
    id: user.id,
    username: user.username,
    name: user.name,
    email: user.email,
    phone: user.phone,
    high_score: user.high_score,
  });
});

// Save high score
app.post("/api/save-score", (req, res) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) {
    return res.status(401).json({ error: "ไม่ได้ล็อกอิน" });
  }

  const token = authHeader.replace("Bearer ", "");
  const userId = sessions.get(token);

  if (!userId) {
    return res.status(401).json({ error: "Session หมดอายุ" });
  }

  const { score } = req.body;
  if (typeof score !== "number") {
    return res.status(400).json({ error: "คะแนนไม่ถูกต้อง" });
  }

  const users = readDb();
  const userIndex = users.findIndex((u) => u.id === userId);

  if (userIndex === -1) {
    return res.status(404).json({ error: "ไม่พบผู้ใช้" });
  }

  const user = users[userIndex];
  let isNewHighScore = false;

  if (score > user.high_score) {
    user.high_score = score;
    isNewHighScore = true;
    users[userIndex] = user;
    writeDb(users);
  }

  res.json({
    message: isNewHighScore ? "ยินดีด้วย! บันทึกสถิติสูงสุดใหม่สำเร็จ" : "คะแนนไม่เกินคะแนนสูงสุดเดิม",
    high_score: user.high_score,
    isNewHighScore,
  });
});

// Leaderboard
app.get("/api/leaderboard", (req, res) => {
  const users = readDb();
  const leaderboard = users
    .map((u) => ({
      username: u.username,
      name: u.name,
      high_score: u.high_score,
    }))
    .sort((a, b) => b.high_score - a.high_score)
    .slice(0, 10);

  res.json(leaderboard);
});

// Setup Vite or production static serving
async function start() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*all", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

start();
